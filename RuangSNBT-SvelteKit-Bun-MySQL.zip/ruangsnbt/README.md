# RuangSNBT — SvelteKit, TypeScript, Bun, MySQL

Penulisan ulang aplikasi CBT RuangSNBT untuk pemilik dan peserta. Antarmuka bahasa Indonesia, data otoritatif di MySQL, dan runtime backend Bun. Ini adalah source code mandiri untuk VM; bukan pembaruan situs versi browser yang sudah terbit.

## Stack

- Svelte 5 + SvelteKit 3 + TypeScript 6.
- Adapter Bun resmi (`@sveltejs/adapter-bun`), Bun 1.4.2 atau lebih baru.
- Bun.SQL, MySQL 8.4 LTS, connection pool maksimum 10 per proses.
- Docker Compose dan Caddy untuk HTTPS.
- CSS responsif, SVG, Plus Jakarta Sans (dengan fallback sans-serif).
- Argon2id untuk kata sandi, session cookie HttpOnly, pemeriksaan Origin untuk mutasi, akses berbasis peran.

Satu aplikasi SvelteKit melayani frontend dan endpoint API. Tidak ada service Node.js terpisah. Node dipakai hanya sebagai alternatif pemeriksaan kompilasi di lingkungan pengembangan tertentu; produksi menggunakan Bun.

## Jalankan paling cepat — Docker Compose

Prasyarat: Docker Engine dan Compose v2; Bun diperlukan hanya untuk pembuatan `.env` otomatis. Alternatifnya salin `.env.example` dan isi sendiri semua rahasia.

```bash
bun scripts/setup-env.ts
# Edit .env: ganti OWNER_EMAIL. Kata sandi awal ada di OWNER_PASSWORD.
docker compose up -d --build
```

Buka **http://localhost:3000**. Masuk dengan `OWNER_EMAIL` dan `OWNER_PASSWORD` dari `.env`.

Layanan `init` menjalankan migrasi, menambahkan 12 soal demo serta satu paket simulasi, lalu membuat pemilik jika belum ada. Menjalankan ulang tidak mereset kata sandi, soal demo yang sudah diedit, atau riwayat. Tidak ada kata sandi bawaan dalam source code.

Jika belum memasang Bun, buat `.env` dengan menyalin `.env.example`. Gunakan dua string hex acak berbeda untuk `MYSQL_PASSWORD` dan `MYSQL_ROOT_PASSWORD`, kata sandi pemilik minimal 12 karakter, dan ubah `DATABASE_URL` agar memakai nilai `MYSQL_PASSWORD` yang sama. Hindari spasi atau karakter URL khusus pada kata sandi database, atau lakukan percent-encoding pada URL koneksi.

Untuk memeriksa startup:

```bash
docker compose ps -a
docker compose logs --tail=100 init app
```

## Pengembangan lokal

```bash
bun install
bun scripts/setup-env.ts          # hanya jika .env belum ada
# Untuk Vite lokal, ubah ORIGIN dalam .env menjadi http://localhost:5173
docker compose -f compose.yaml -f compose.dev.yaml up -d db
bun run db:migrate
bun run db:seed
bun run owner:create
bun run dev
```

Buka **http://localhost:5173**. Jalankan `bun run check`, `bun test tests/domain.test.ts`, dan `bun run build` sebelum rilis. Untuk menjalankan hasil build lokal, gunakan `ORIGIN=http://localhost:3000 bun run start`.

`package-lock.json` mencatat versi dependensi yang telah diperiksa. Bun dapat mengimpor lockfile npm pada `bun install` dan menghasilkan `bun.lock`. Commit `bun.lock` yang dihasilkan sebelum pengembangan berikutnya; setelah itu gunakan `bun install --frozen-lockfile`. Tidak ada `node_modules`, `.env`, atau data pengguna di ZIP.

## Publikasi ke VM

Awal yang disarankan: **2 vCPU, 4 GB RAM, SSD 60–80 GB**, lokasi dekat peserta. Kapasitas 50 peserta tetap harus dibuktikan lewat uji beban di VM target; spesifikasi ini bukan jaminan.

1. Arahkan DNS domain ke IP VM. Izinkan inbound TCP 80/443 dan UDP 443 untuk Caddy, serta SSH sesuai kebutuhan operator. Jangan buka port MySQL ke internet.
2. Buat `.env` dengan nilai acak. Isi `DOMAIN=cbt.domainanda.com` dan `ORIGIN=https://cbt.domainanda.com` (tanpa trailing slash).
3. Jalankan:

```bash
docker compose --profile production up -d --build
```

Caddy mengurus HTTPS. MySQL hanya dapat dijangkau pada jaringan internal Compose; port aplikasi di host terikat ke `127.0.0.1`. Jangan gunakan `compose.dev.yaml` di produksi.

`ORIGIN` wajib sesuai alamat yang dipakai pengguna. Dengan HTTPS, session cookie otomatis menggunakan atribut Secure. Session berlaku 7 hari; logout menghapus sesi server. Akun peserta dibuat lewat Pengaturan. Pemilik dapat mengganti kata sandi peserta dan mencabut sesi mereka.

Untuk memperbarui versi: cadangkan database, ganti source, lalu jalankan perintah Compose di atas. `init` harus selesai dengan exit code 0. Migrasi berikutnya harus memakai berkas baru; jangan mengubah migrasi yang sudah diterapkan. Volume database tetap dipertahankan; `docker compose down -v` akan menghapusnya.

## Alur yang tersedia

1. Masuk sebagai pemilik; tambah soal dengan kunci dan pembahasan.
2. Susun paket, pilih bagian/soal/durasi, lalu aktifkan.
3. Buat akun peserta melalui Pengaturan dan masuk sebagai peserta di browser lain.
4. Mulai tryout, pilih jawaban dan tandai ragu-ragu.
5. Refresh, lalu pilih **Lanjutkan Pengerjaan**. Timer mengikuti deadline server dan tidak diulang.
6. Kirim bagian, lihat hasil internal serta pembahasan.
7. Kerjakan ulang; percobaan baru masuk riwayat tanpa menimpa percobaan sebelumnya.
8. Latihan Topik membuka pembahasan hanya setelah jawaban pertama dikonfirmasi server.
9. Ekspor/impor JSON konten; gunakan backup MySQL untuk cadangan seluruh data.

Dashboard tidak berisi hasil pengguna palsu. Grafik muncul setelah dua percobaan selesai untuk paket/topik yang sama. Evaluasi topik memerlukan sedikitnya tiga soal. Data demo diberi label dan bukan soal resmi SNBT.

## Konsistensi ujian dan offline

- Setiap percobaan menyimpan snapshot soal, pilihan, kunci, pembahasan, urutan acak, dan pengaturan paket. Perubahan bank soal tidak mengubah snapshot.
- API peserta tidak mengirim kunci/pembahasan selama simulasi aktif. Pada latihan, hanya soal yang sudah dikonfirmasi yang membuka pembahasan. Pemilik memang memiliki hak melihat kunci di bank soal.
- Deadline disimpan sebagai epoch milidetik di server. Penilaian menggunakan waktu server, bukan jam perangkat.
- Perubahan jawaban memakai revisi, transaksi MySQL, dan penguncian baris percobaan. Pengiriman berulang untuk bagian yang sama aman; hasil tidak dibuat dua kali.
- Saat koneksi terputus pada halaman ujian yang sudah terbuka, perubahan masuk antrean lokal, terikat akun dan percobaan. Antrean dipulihkan saat sesi dibuka kembali dan dikirim ketika online.
- **Jawaban yang baru sampai di server setelah deadline ditolak**, walaupun peserta memilihnya ketika offline. Tidak ada klaim bahwa waktu pilih di browser dapat dipercaya.
- Timer UI bergerak lokal dengan selisih waktu server. Tidak ada request per detik selama waktu belum habis. Penyegaran server setiap 15 detik; jawaban disimpan segera ketika berubah.
- Bagian berikutnya dimulai pada waktu submit, atau deadline sebelumnya jika waktu habis. Saat tab ditutup lama, beberapa bagian dapat selesai sekaligus berdasarkan deadline. Finalisasi dilakukan saat request berikutnya, dengan waktu akhir logis tetap deadline.
- Membuka aplikasi dari awal saat sepenuhnya offline belum didukung. Hindari dua tab/perangkat mengerjakan percobaan yang sama. Satu akun hanya mempunyai satu percobaan aktif.

## Cadangan dan pemulihan

**JSON aplikasi:** Pengaturan → Ekspor Cadangan. Isinya soal, versi soal, dan paket. Impor divalidasi lalu digabung berdasarkan ID: soal lama memperoleh versi baru, percobaan dan akun tidak dihapus. Cadangan JSON memuat kunci soal; hanya pemilik dapat mengekspornya.

**Seluruh MySQL:** mencakup akun, hash kata sandi, sesi, soal, paket, jawaban dan hasil.

```bash
sh scripts/backup.sh
# Salin .sql.gz ke lokasi terpisah dari VM dan batasi aksesnya.
CONFIRM_RESTORE=YES sh scripts/restore.sh backups/ruangsnbt-TANGGAL.sql.gz
```

Pemulihan mengganti isi tabel dalam database saat ini. Cadangkan dahulu dan uji restore pada database sementara secara berkala. Skrip menghentikan aplikasi selama restore; jika terjadi kegagalan, aplikasi dibiarkan berhenti agar data tidak berubah di tengah pemulihan. Aktifkan jadwal backup harian melalui cron/timer VM, dan simpan salinan di luar VM.

**Dari aplikasi browser versi sebelumnya:** ekspor cadangan JSON dari situs lama. Selesaikan seluruh sesi aktif sebelum ekspor. Setelah membuat pemilik pada versi baru:

```bash
# Lokal, memakai DATABASE_URL dalam .env:
bun scripts/import-legacy.ts /path/cadangan-versi-lama.json pemilik@domain.com

# Docker:
docker compose cp /path/cadangan-versi-lama.json app:/tmp/legacy.json
docker compose exec app bun scripts/import-legacy.ts /tmp/legacy.json pemilik@domain.com
```

Skrip mengimpor soal/paket dan riwayat selesai ke akun pemilik yang dipilih. Riwayat dengan ID yang sudah ada dilewati. Data dari browser lain tidak diambil otomatis. Operasi konten dan riwayat memakai transaksi terpisah; pengulangan aman untuk ID riwayat, tetapi konten dengan ID sama akan mendapat versi baru lagi.

## Pengujian

```bash
bun run check
bun test tests/domain.test.ts
bun run build
```

Pengujian integrasi memerlukan server berjalan dengan database **staging terpisah**, karena akan membuat soal, paket dan peserta uji:

```bash
TEST_BASE_URL=http://localhost:3000 \
TEST_OWNER_EMAIL=pemilik@example.com \
TEST_OWNER_PASSWORD='kata-sandi-staging' \
bun test tests/integration.test.ts
```

Tes integrasi memeriksa otorisasi pemilik/peserta, CSRF Origin, membuat soal/paket, snapshot, penyimpanan jawaban/ragu-ragu, refresh, idempotensi submit paralel, nilai, percobaan ulang, serta ekspor/impor konten. Jika environment test belum diisi, tes integrasi dilewati secara eksplisit.

`bun scripts/load-test.ts` memakai variabel yang sama untuk smoke test 50 koneksi baca bersamaan. Ini **bukan** simulasi penuh 50 peserta: masih perlu uji login, autosave, mulai dan submit serentak dengan akun terpisah. Catat p95 latency, error rate, CPU, RAM, dan koneksi database. Hasil verifikasi saat source disiapkan dijelaskan di `docs/VERIFIKASI.md`.

## Struktur proyek

| Lokasi                                | Isi                                                      |
| ------------------------------------- | -------------------------------------------------------- |
| `src/lib/components`                  | Komponen dashboard, editor, ujian, hasil, pengaturan     |
| `src/routes/+page.svelte`             | Navigasi dan penyambungan alur aplikasi                  |
| `src/routes/login`                    | Halaman masuk                                            |
| `src/routes/api/[...path]/+server.ts` | Endpoint autentikasi, konten, percobaan dan backup       |
| `src/lib/server/domain.ts`            | Timer, snapshot, penilaian, penyaringan kunci            |
| `src/lib/server/repository.ts`        | Query dan transaksi MySQL                                |
| `src/lib/server/auth.ts`              | Hash kata sandi, sesi, pembatasan login                  |
| `src/lib/server/validation.ts`        | Validasi server dan pesan per kolom                      |
| `migrations`                          | Skema database SQL                                       |
| `scripts`                             | Migrasi, demo, pemilik, backup/restore, impor versi lama |
| `tests`                               | Tes domain dan integrasi                                 |

## Batasan versi ini

- Mendukung pilihan ganda satu jawaban. Jenis soal disimpan eksplisit untuk pengembangan berikutnya.
- Rumus menggunakan karakter Unicode/teks; belum ada editor LaTeX. Tabel memakai pemisah `|`. Gambar PNG/JPEG/WebP maksimal 600 KB disimpan sebagai data URI dalam JSON MySQL; untuk bank soal besar, pindahkan media ke object storage.
- Tidak ada email reset otomatis, pendaftaran publik, pembayaran, leaderboard, atau proctoring.
- JSON melalui UI adalah backup konten. Backup seluruh data menggunakan MySQL atau migrasi versi lama yang dijelaskan di atas.
- Belum ada pemisahan organisasi, pagination server untuk bank soal, ataupun high availability. Satu VM menjadi titik kegagalan tunggal.
- Belum dibuktikan menangani 50 peserta pada VM tertentu; lakukan uji integrasi dan beban sebelum dipakai bersama.

## Referensi teknologi

- https://svelte.dev/docs/kit/adapter-bun
- https://svelte.dev/docs/kit/migrating-to-sveltekit-3
- https://bun.sh/docs/runtime/sql
