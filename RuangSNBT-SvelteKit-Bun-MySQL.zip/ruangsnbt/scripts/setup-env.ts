import { randomBytes } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
const mysql = randomBytes(24).toString('hex'),
  root = randomBytes(24).toString('hex'),
  owner = randomBytes(18).toString('base64url');
const text = `# Ganti email dan domain sebelum produksi. Jangan commit file ini.\nMYSQL_PASSWORD=${mysql}\nMYSQL_ROOT_PASSWORD=${root}\nDATABASE_URL=mysql://ruangsnbt:${mysql}@127.0.0.1:3306/ruangsnbt\nOWNER_EMAIL=pemilik@example.com\nOWNER_NAME=Pemilik\nOWNER_PASSWORD=${owner}\nORIGIN=http://localhost:3000\nDOMAIN=cbt.example.com\n`;
await writeFile('.env', text, { flag: 'wx', mode: 0o600 });
console.log(
  '.env dibuat dengan kata sandi acak. Buka file secara lokal, ubah OWNER_EMAIL dan ORIGIN. Kata sandi tidak ditampilkan di log.',
);
