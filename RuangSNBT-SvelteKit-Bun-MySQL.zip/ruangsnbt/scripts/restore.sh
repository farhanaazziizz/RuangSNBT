#!/bin/sh
set -eu
if [ "$#" -ne 1 ] || [ "${CONFIRM_RESTORE:-}" != "YES" ]; then
  echo 'Mengganti database saat ini. Gunakan: CONFIRM_RESTORE=YES sh scripts/restore.sh backups/berkas.sql.gz'
  exit 1
fi
# Validate compression before stopping services or changing data.
gzip -t "$1"
docker compose stop app
uncompressed="$(mktemp)"
trap 'rm -f "$uncompressed"' EXIT
gzip -dc "$1" > "$uncompressed"
docker compose exec -T db sh -c 'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" exec mysql -uroot ruangsnbt' < "$uncompressed"
docker compose up -d app
printf 'Pemulihan selesai.\n'
