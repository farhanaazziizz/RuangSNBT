import { createUser } from '../src/lib/server/auth.ts';
import { db } from '../src/lib/server/db.ts';
const email = process.env.OWNER_EMAIL,
  password = process.env.OWNER_PASSWORD,
  name = process.env.OWNER_NAME || 'Pemilik';
if (!email || !password) throw Error('Isi OWNER_EMAIL dan OWNER_PASSWORD (12–128 karakter).');
if ((await db()`SELECT id FROM users WHERE role='owner'`).length)
  console.log('Pemilik sudah ada; tidak diubah.');
else {
  await createUser({ email, name, password, role: 'owner' });
  console.log('Akun pemilik dibuat.');
}
await db().close();
