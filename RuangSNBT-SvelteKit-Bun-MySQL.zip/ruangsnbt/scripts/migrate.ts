import { db } from '../src/lib/server/db.ts';
import { readdir } from 'node:fs/promises';
const sql = db();
await sql`CREATE TABLE IF NOT EXISTS schema_migrations (name VARCHAR(200) PRIMARY KEY, applied_at BIGINT NOT NULL)`;
// Run once, before starting the app. MySQL DDL commits implicitly; each migration is repeatable.
for (const name of (await readdir('migrations')).filter((n) => n.endsWith('.sql')).sort()) {
  if ((await sql`SELECT name FROM schema_migrations WHERE name=${name}`).length) continue;
  const content = await Bun.file('migrations/' + name).text();
  for (const statement of content
    .split(';')
    .map((s) => s.trim())
    .filter(Boolean))
    await sql.unsafe(statement);
  await sql`INSERT INTO schema_migrations (name,applied_at) VALUES (${name},${Date.now()})`;
  console.log('Migrasi selesai:', name);
}
await sql.close();
