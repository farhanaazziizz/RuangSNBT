#!/bin/sh
set -eu
umask 077
mkdir -p backups
file="backups/ruangsnbt-$(date -u +%Y%m%dT%H%M%SZ).sql"
# Dump to a file first; only compress after successful completion so failures cannot look successful.
docker compose exec -T db sh -c 'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" exec mysqldump -uroot --single-transaction --routines --triggers --set-gtid-purged=OFF ruangsnbt' > "$file"
gzip "$file"
printf 'Cadangan dibuat: %s.gz\n' "$file"
