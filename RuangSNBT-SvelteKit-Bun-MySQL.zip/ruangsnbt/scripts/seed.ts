import { seedContent } from '../src/lib/server/repository.ts';
import { db } from '../src/lib/server/db.ts';
import { demo } from './demo.ts';
await seedContent(demo);
console.log('12 soal demo dan satu paket tersedia. Data lama tidak ditimpa.');
await db().close();
