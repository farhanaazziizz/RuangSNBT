/** Run only by the operator with DB credentials, after exporting the old browser app. */
import { readFile } from 'node:fs/promises';
import { db } from '../src/lib/server/db.ts';
import { validateBackup, validateQuestion } from '../src/lib/server/validation.ts';
import { importContent } from '../src/lib/server/repository.ts';
import { score } from '../src/lib/server/domain.ts';
import type { Question, Attempt, Backup } from '../src/lib/types.ts';
const [path, email] = process.argv.slice(2);
if (!path || !email)
  throw Error('Penggunaan: bun scripts/import-legacy.ts cadangan-v1.json email-pemilik');
const old = JSON.parse(await readFile(path, 'utf8'));
if (
  old.schemaVersion !== 1 ||
  !Array.isArray(old.questions) ||
  !Array.isArray(old.packages) ||
  !Array.isArray(old.attempts)
)
  throw Error('Bukan cadangan RuangSNBT versi browser.');
const [user] = await db()`SELECT id FROM users WHERE email=${email.toLowerCase()} AND role='owner'`;
if (!user) throw Error('Pemilik tidak ditemukan.');
if (old.attempts.some((a: any) => a.status !== 'done'))
  throw Error(
    'Selesaikan sesi aktif di aplikasi lama lalu ekspor ulang agar riwayat tidak kehilangan jawaban.',
  );
const normalize = (q: any): Question =>
  validateQuestion({
    ...q,
    table: q.table || '',
    image: q.image || '',
    alt: q.alt || '',
    source: q.source || '',
    archived: !!q.archived,
  });
const content: Backup = validateBackup({
  format: 'ruangsnbt-content',
  version: 2,
  questions: old.questions.map(normalize),
  packages: old.packages,
  questionVersions: (old.questionVersions || []).map(normalize),
});
const attempts: Attempt[] = old.attempts.map((a: any) => {
  if (
    !Array.isArray(a.sections) ||
    !a.sections.length ||
    !Number.isFinite(a.started) ||
    !Number.isFinite(a.ended)
  )
    throw Error('Riwayat lama tidak valid.');
  const result: Attempt = {
    ...a,
    userId: user.id,
    packageId: content.packages.some((p) => p.id === a.packageId) ? a.packageId : null,
    allowBack: !!a.allowBack,
    answers: {},
    sections: a.sections.map((s: any) => ({
      ...s,
      questions: s.questions.map((q: any) => ({ ...normalize(q), instanceId: q.instanceId })),
      elapsed: Number(s.elapsed) || 0,
    })),
  };
  for (const q of result.sections.flatMap((s) => s.questions)) {
    if (typeof q.instanceId !== 'string' || q.instanceId.length > 64)
      throw Error('Identitas soal percobaan tidak valid.');
    const value = a.answers[q.instanceId];
    if (value !== undefined && (!Number.isInteger(value) || value < 0 || value >= q.options.length))
      throw Error('Jawaban lama tidak valid.');
    result.answers[q.instanceId] = {
      option: value ?? null,
      flagged: !!a.flags?.[q.instanceId],
      confirmed: !!a.confirmed?.[q.instanceId],
      revision: 1,
    };
  }
  result.elapsed = result.sections.reduce((n, s) => n + s.elapsed, 0);
  result.result = score(
    result,
    result.sections.flatMap((s) => s.questions),
  );
  return result;
});
await importContent(content);
let imported = 0;
await db().begin(async (tx) => {
  for (const a of attempts) {
    if ((await tx`SELECT id FROM attempts WHERE id=${a.id}`).length) continue;
    const { answers, ...snapshot } = a;
    await tx`INSERT INTO attempts (id,user_id,package_id,status,started_at,ended_at,snapshot,result) VALUES (${a.id},${user.id},${a.packageId},'done',${a.started},${a.ended},${JSON.stringify(snapshot)},${JSON.stringify(a.result)})`;
    for (const [id, v] of Object.entries(answers))
      await tx`INSERT INTO answers (attempt_id,question_id,option_index,flagged,confirmed,revision,updated_at) VALUES (${a.id},${id},${v.option},${v.flagged},${v.confirmed},1,${a.ended})`;
    imported++;
  }
});
console.log(
  `Konten diimpor; ${imported} riwayat ditambahkan ke akun pemilik. Sesi dengan ID sama dilewati.`,
);
await db().close();
