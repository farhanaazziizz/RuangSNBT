/** Non-destructive read-load smoke test. For realistic answer traffic use 50 separately seeded staging accounts. */
const base = process.env.TEST_BASE_URL,
  email = process.env.TEST_OWNER_EMAIL,
  password = process.env.TEST_OWNER_PASSWORD;
if (!base || !email || !password)
  throw Error('Isi TEST_BASE_URL, TEST_OWNER_EMAIL, TEST_OWNER_PASSWORD pada staging.');
const origin = new URL(base).origin;
const login = await fetch(base + '/api/auth/login', {
  method: 'POST',
  headers: { Origin: origin, 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password }),
});
if (!login.ok) throw Error('Login gagal.');
const cookie = login.headers.get('set-cookie')!.split(';')[0],
  times: number[] = [];
let failures = 0;
await Promise.all(
  Array.from({ length: 50 }, async () => {
    for (let i = 0; i < 10; i++) {
      const start = performance.now();
      const response = await fetch(base + '/api/bootstrap', { headers: { Cookie: cookie } });
      await response.arrayBuffer();
      times.push(performance.now() - start);
      if (!response.ok) failures++;
      await Bun.sleep(1000);
    }
  }),
);
times.sort((a, b) => a - b);
console.log({
  requests: times.length,
  failures,
  p50_ms: Math.round(times[Math.floor(times.length * 0.5)]),
  p95_ms: Math.round(times[Math.floor(times.length * 0.95)]),
});
