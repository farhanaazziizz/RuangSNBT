import adapter from '@sveltejs/adapter-bun';
import { sveltekit } from '@sveltejs/kit/vite';
import { defineConfig } from 'vite';
export default defineConfig({
  plugins: [sveltekit({ adapter: process.env.CHECK_BUILD === '1' ? undefined : adapter() })],
  ssr: { external: ['bun'] },
});
