import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  createAttempt,
  saveAnswer,
  publicAttempt,
  advanceExpired,
  finishSection,
  score,
} from '../src/lib/server/domain.ts';
import { validateBackup, validateQuestion, validatePackage } from '../src/lib/server/validation.ts';
import { demo } from '../scripts/demo.ts';
const make = () => createAttempt(demo.packages[0], demo.questions, 'student', 1000000);
test('simulasi tidak membocorkan kunci atau pembahasan', () => {
  const a = make(),
    p = publicAttempt(a, 1000000);
  assert.ok(
    p.sections.flatMap((s) => s.questions).every((q) => !('key' in q) && !('explanation' in q)),
  );
});
test('jawaban dan ragu-ragu pulih tanpa timer berubah; snapshot tidak mengikuti edit', () => {
  const a = make(),
    q = a.sections[0].questions[0],
    deadline = a.sections[0].deadline;
  saveAnswer(
    a,
    { questionId: q.instanceId, option: q.key, flagged: true, confirm: false, revision: 1 },
    1000001,
  );
  const reloaded = JSON.parse(JSON.stringify(a));
  assert.equal(reloaded.answers[q.instanceId].option, q.key);
  assert.equal(reloaded.sections[0].deadline, deadline);
  const original = demo.questions[0].text;
  demo.questions[0].text = 'Diubah';
  assert.equal(q.text, original);
  demo.questions[0].text = original;
});
test('timer kedaluwarsa memajukan semua bagian sesuai deadline tersimpan', () => {
  const a = make();
  advanceExpired(a, 1000000 + 360000);
  assert.equal(a.sectionIndex, 1);
  assert.equal(a.sections[1].started, 1360000);
  advanceExpired(a, 1000000 + 16 * 60000);
  assert.equal(a.status, 'done');
  assert.equal(a.result?.empty, 8);
});
test('server menolak jawaban terlambat dan bagian lain yang belum aktif', () => {
  const a = make(),
    q = a.sections[0].questions[0];
  assert.throws(() =>
    saveAnswer(
      a,
      {
        questionId: a.sections[1].questions[0].instanceId,
        option: 0,
        flagged: false,
        confirm: false,
        revision: 1,
      },
      1000001,
    ),
  );
  assert.throws(() =>
    saveAnswer(
      a,
      { questionId: q.instanceId, option: 0, flagged: false, confirm: false, revision: 1 },
      1360000,
    ),
  );
});
test('latihan mengunci jawaban pertama dan membuka hanya pembahasan terkait', () => {
  const p = structuredClone(demo.packages[0]);
  p.mode = 'latihan';
  const a = createAttempt(p, demo.questions, 'student', 1000000),
    q = a.sections[0].questions[0];
  saveAnswer(
    a,
    { questionId: q.instanceId, option: q.key, flagged: false, confirm: true, revision: 1 },
    1000001,
  );
  assert.equal(publicAttempt(a, 1000001).sections[0].questions[0].key, q.key);
  assert.equal(publicAttempt(a, 1000001).sections[0].questions[1].key, undefined);
  assert.throws(() =>
    saveAnswer(
      a,
      {
        questionId: q.instanceId,
        option: (q.key + 1) % 4,
        flagged: false,
        confirm: true,
        revision: 2,
      },
      1000002,
    ),
  );
});
test('retry jawaban idempoten; hasil benar/salah/kosong konsisten', () => {
  const a = make(),
    [q1, q2] = a.sections[0].questions;
  const payload = {
    questionId: q1.instanceId,
    option: q1.key,
    flagged: true,
    confirm: false,
    revision: 1,
  };
  saveAnswer(a, payload, 1000001);
  saveAnswer(a, payload, 1000002);
  saveAnswer(a, { ...payload, questionId: q2.instanceId, option: (q2.key + 1) % 4 }, 1000003);
  assert.deepEqual(score(a, a.sections[0].questions), {
    total: 3,
    correct: 1,
    wrong: 1,
    empty: 1,
    accuracy: 33,
  });
  while (a.status === 'active') finishSection(a, 1000004);
  const result = publicAttempt(a, 1000004);
  assert.equal(result.result?.correct, 1);
  assert.ok(result.sections[0].questions[0].explanation);
});
test('acak tetap konsisten setelah serialisasi, percobaan baru terpisah', () => {
  const p = { ...demo.packages[0], shuffleQuestions: true, shuffleOptions: true },
    a = createAttempt(p, demo.questions, 'student', 0);
  assert.deepEqual(JSON.parse(JSON.stringify(a)).sections, a.sections);
  assert.notEqual(make().id, make().id);
  for (const q of a.sections.flatMap((s) => s.questions)) {
    const original = demo.questions.find((o) => o.id === q.id)!;
    assert.equal(q.options[q.key], original.options[original.key]);
  }
});
test('backup roundtrip valid dan kunci invalid ditolak', () => {
  const good = validateBackup(JSON.parse(JSON.stringify(demo)));
  assert.equal(good.questions.length, 12);
  const bad = structuredClone(demo);
  bad.questions[0].key = 99;
  assert.throws(() => validateBackup(bad));
});
test('soal siap butuh pembahasan, paket aktif butuh soal', () => {
  assert.throws(() => validateQuestion({ ...demo.questions[0], explanation: '' }));
  assert.throws(() =>
    validatePackage(
      { ...demo.packages[0], sections: [{ ...demo.packages[0].sections[0], questionIds: [] }] },
      demo.questions,
    ),
  );
});
