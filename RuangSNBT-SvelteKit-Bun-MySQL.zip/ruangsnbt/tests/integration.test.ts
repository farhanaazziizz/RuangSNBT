import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { Question, ExamPackage, PublicAttempt, Bootstrap, Backup } from '../src/lib/types.ts';
const base = process.env.TEST_BASE_URL,
  ownerEmail = process.env.TEST_OWNER_EMAIL,
  ownerPassword = process.env.TEST_OWNER_PASSWORD;
// Use a disposable staging database. These tests intentionally create content and participant accounts.
test(
  'alur HTTP: otorisasi → soal → paket → refresh → hasil → ulang → cadangan',
  { skip: !base || !ownerEmail || !ownerPassword, timeout: 60000 },
  async () => {
    const origin = new URL(base!).origin;
    async function request(path: string, method = 'GET', body?: unknown, cookie = '') {
      const response = await fetch(base! + '/api/' + path, {
        method,
        headers: {
          Origin: origin,
          ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
          ...(cookie ? { Cookie: cookie } : {}),
        },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      return { response, data: (await response.json()) as any };
    }
    const auth = await request('auth/login', 'POST', {
      email: ownerEmail,
      password: ownerPassword,
    });
    assert.equal(auth.response.status, 200);
    const owner = auth.response.headers.get('set-cookie')!.split(';')[0];
    assert.equal((await request('bootstrap')).response.status, 401);
    const suffix = crypto.randomUUID(),
      password = 'Test-' + crypto.randomUUID();
    const create = await request(
      'users',
      'POST',
      { name: 'Peserta uji', email: `test-${suffix}@example.test`, password },
      owner,
    );
    assert.equal(create.response.status, 200);
    const login = await request('auth/login', 'POST', {
      email: `test-${suffix}@example.test`,
      password,
    });
    const student = login.response.headers.get('set-cookie')!.split(';')[0];
    assert.equal((await request('questions', 'POST', {}, student)).response.status, 403);
    assert.equal(
      (
        await fetch(base! + '/api/profile', {
          method: 'PATCH',
          headers: {
            Cookie: student,
            'Content-Type': 'application/json',
            Origin: 'https://example.invalid',
          },
          body: '{"name":"x"}',
        })
      ).status,
      403,
    );
    const question: Question = {
      id: crypto.randomUUID(),
      version: 1,
      section: 'Penalaran Umum',
      topic: 'Uji Integrasi ' + suffix,
      type: 'single',
      text: 'Berapakah 2 + 2?',
      options: ['3', '4', '5', '6'],
      key: 1,
      explanation: '2 + 2 = 4.',
      difficulty: 'Mudah',
      status: 'ready',
      demo: false,
      archived: false,
      image: '',
      alt: '',
      table: '',
      source: '',
    };
    const saved = await request('questions', 'POST', question, owner);
    assert.equal(saved.response.status, 200);
    const p: ExamPackage = {
      id: crypto.randomUUID(),
      name: 'Paket Uji ' + suffix,
      description: 'Pengujian integrasi',
      mode: 'simulasi',
      status: 'ready',
      demo: false,
      allowBack: false,
      shuffleOptions: false,
      shuffleQuestions: false,
      sections: [
        {
          id: crypto.randomUUID(),
          name: question.section,
          duration: 10,
          questionIds: [question.id],
        },
      ],
    };
    assert.equal((await request('packages', 'POST', p, owner)).response.status, 200);
    const first = await request('attempts', 'POST', { packageId: p.id }, student);
    assert.equal(first.response.status, 200);
    const a = first.data as PublicAttempt,
      q = a.sections[0].questions[0],
      deadline = a.sections[0].deadline;
    assert.equal(q.key, undefined);
    assert.equal(q.explanation, undefined);
    assert.equal((await request('attempts/' + a.id, 'GET', undefined, owner)).response.status, 404);
    const answer = {
      questionId: q.instanceId,
      option: 1,
      flagged: true,
      confirm: false,
      revision: 1,
    };
    assert.equal(
      (await request('attempts/' + a.id + '/answers', 'PUT', answer, student)).response.status,
      200,
    );
    await request(
      'questions',
      'POST',
      { ...saved.data, text: 'Isi baru setelah sesi dimulai' },
      owner,
    );
    const reload = (await request('attempts/' + a.id, 'GET', undefined, student))
      .data as PublicAttempt;
    assert.equal(reload.sections[0].deadline, deadline);
    assert.equal(reload.sections[0].questions[0].text, question.text);
    assert.equal(reload.answers[q.instanceId].option, 1);
    assert.equal(reload.answers[q.instanceId].flagged, true);
    const [done1, done2] = await Promise.all([
      request('attempts/' + a.id + '/submit', 'POST', { sectionIndex: 0 }, student),
      request('attempts/' + a.id + '/submit', 'POST', { sectionIndex: 0 }, student),
    ]);
    assert.equal(done1.data.result.accuracy, 100);
    assert.equal(done2.data.result.accuracy, 100);
    assert.equal(done1.data.sections[0].questions[0].key, 1);
    const second = (await request('attempts', 'POST', { packageId: p.id }, student))
      .data as PublicAttempt;
    assert.notEqual(second.id, a.id);
    await request(
      'attempts/' + second.id + '/answers',
      'PUT',
      { ...answer, questionId: second.sections[0].questions[0].instanceId, option: 0 },
      student,
    );
    assert.equal(
      (await request('attempts/' + second.id + '/submit', 'POST', { sectionIndex: 0 }, student))
        .data.result.accuracy,
      0,
    );
    const boot = (await request('bootstrap', 'GET', undefined, student)).data as Bootstrap;
    assert.equal(boot.questions.length, 0);
    assert.equal(boot.attempts.filter((a) => a.packageId === p.id).length, 2);
    const backup = (await request('backup', 'GET', undefined, owner)).data as Backup;
    assert.equal((await request('backup/validate', 'POST', backup, owner)).response.status, 200);
    assert.equal((await request('backup/import', 'POST', backup, owner)).response.status, 200);
    const broken = structuredClone(backup);
    broken.questions[0].key = 99;
    assert.equal((await request('backup/import', 'POST', broken, owner)).response.status, 400);
  },
);
