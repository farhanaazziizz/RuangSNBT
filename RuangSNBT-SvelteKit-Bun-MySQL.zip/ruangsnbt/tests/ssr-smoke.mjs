// @ts-nocheck
// Run under Node after CHECK_BUILD=1 vite build; no MySQL required for these boundaries.
const { Server } = await import(
  new URL('../.svelte-kit/output/server/index.js', import.meta.url).href
);
const { manifest } = await import(
  new URL('../.svelte-kit/output/server/manifest.js', import.meta.url).href
);
import assert from 'node:assert/strict';
const server = new Server(manifest);
await server.init({ env: { ORIGIN: 'http://localhost:3000' } });
const request = (path, init) =>
  server.respond(new Request('http://localhost:3000' + path, init), {
    getClientAddress: () => '127.0.0.1',
  });
const login = await request('/login');
assert.equal(login.status, 200);
assert.ok((await login.text()).includes('Selamat datang kembali'));
const root = await request('/');
assert.equal(root.status, 303);
assert.equal(root.headers.get('location'), '/login');
const blocked = await request('/api/bootstrap');
assert.equal(blocked.status, 401);
const csrf = await request('/api/auth/login', {
  method: 'POST',
  headers: { Origin: 'https://other.invalid', 'Content-Type': 'application/json' },
  body: '{}',
});
assert.equal(csrf.status, 403);
console.log('PASS: login SSR, redirect tamu, API privat 401, Origin asing 403.');
