# Arsitektur RuangSNBT

## Aliran permintaan

Browser mengakses Caddy (TLS), diteruskan ke server SvelteKit pada Bun, lalu query MySQL melalui pool Bun.SQL. Satu VM cukup sebagai konfigurasi awal. Caddy hanya diperlukan pada profil produksi Compose.

- `hooks.server.ts`: memeriksa Origin untuk mutasi dan mencari session cookie di MySQL.
- Endpoint API: memeriksa autentikasi dan hak pemilik, memvalidasi input, lalu memanggil service.
- `repository.ts`: mengelola transaksi dan serialisasi snapshot.
- `domain.ts`: logika penilaian dan deadline yang tidak bergantung database.
- Komponen Svelte: hanya menerima bentuk data yang aman bagi perannya.

## Tabel

| Tabel             | Tanggung jawab                                             |
| ----------------- | ---------------------------------------------------------- |
| users             | Profil, email unik, hash kata sandi, peran                 |
| sessions          | Hash token sesi dan waktu kedaluwarsa                      |
| login_limits      | Pembatasan percobaan login per email                       |
| topics            | Identitas bagian dan topik                                 |
| questions         | Versi terkini dan status soal                              |
| question_versions | Arsip versi soal yang pernah disimpan                      |
| packages          | Metadata dan pengaturan paket                              |
| package_sections  | Urutan, durasi, dan referensi soal tiap bagian             |
| attempts          | Pemilik percobaan, snapshot soal/paket, deadline dan hasil |
| answers           | Pilihan, ragu-ragu, konfirmasi latihan, revisi jawaban     |
| schema_migrations | Migrasi yang sudah diterapkan                              |

Snapshot menggunakan JSON agar stimulus, tabel, gambar dan pilihan dapat berkembang tanpa mengubah percobaan lama. Jawaban tetap berada di tabel terpisah dengan primary key `(attempt_id, question_id)`. Result merupakan hasil turunan snapshot dan jawaban.

## Kontrak API utama

Seluruh mutasi menggunakan JSON, cookie sesi, dan Origin yang sama dengan `ORIGIN`. Endpoint konten hanya boleh diakses pemilik. Semua percobaan dibatasi `user_id` dari sesi, bukan ID pengguna dalam body.

| Metode & path                 | Akses                      | Fungsi                                                                     |
| ----------------------------- | -------------------------- | -------------------------------------------------------------------------- |
| POST /api/auth/login          | Publik, dibatasi percobaan | Buat sesi                                                                  |
| POST /api/auth/logout         | Login                      | Cabut sesi                                                                 |
| GET /api/bootstrap            | Login                      | Profil, paket, topik, riwayat milik sendiri; bank soal hanya untuk pemilik |
| PATCH /api/profile            | Login                      | Ubah nama sendiri                                                          |
| POST /api/questions           | Pemilik                    | Tambah/edit/arsip/duplikat soal                                            |
| POST /api/packages            | Pemilik                    | Tambah/edit paket beserta bagiannya                                        |
| POST /api/attempts            | Login                      | Mulai paket atau latihan topik, atau kembalikan sesi aktif                 |
| GET /api/attempts/:id         | Pemilik percobaan          | Pulihkan dan sinkronkan sesi                                               |
| PUT /api/attempts/:id/answers | Pemilik percobaan          | Simpan jawaban, ragu-ragu, konfirmasi latihan                              |
| POST /api/attempts/:id/submit | Pemilik percobaan          | Finalisasi bagian secara idempoten                                         |
| GET/POST /api/users           | Pemilik                    | Daftar/buat peserta                                                        |
| POST /api/users/password      | Pemilik                    | Reset kata sandi peserta, cabut sesi                                       |
| GET /api/backup               | Pemilik                    | Cadangan JSON konten                                                       |
| POST /api/backup/validate     | Pemilik                    | Validasi tanpa menulis                                                     |
| POST /api/backup/import       | Pemilik                    | Gabungkan konten dalam transaksi                                           |

Jawaban: `{questionId, option, flagged, confirm, revision}`. `option` berupa indeks atau null. `revision` naik per perubahan pada satu soal. Revisi lama tidak menimpa revisi baru. Konfirmasi pertama pada latihan bersifat tetap.

Submit: `{sectionIndex}`. Server mengunci baris attempt, memajukan deadline yang sudah habis, lalu hanya memfinalisasi bagian yang diminta jika masih bagian aktif. Retry untuk bagian sebelumnya mengembalikan kondisi terkini tanpa memfinalisasi bagian berikutnya.

## Catatan operasional

- Satu akun dibatasi satu attempt aktif dengan penguncian baris pengguna ketika mulai sesi.
- Setiap operasi jawaban mengunci baris percobaan; hanya jawaban yang revisinya berubah ditulis kembali.
- Deadline tidak bergantung pada proses timer di memori server. Restart tidak mereset waktu.
- Tidak ada background worker untuk finalisasi pada detik deadline. Evaluasi dilakukan ketika request berikutnya datang; hasil memakai waktu deadline asli, bukan waktu request.
- Antrean offline berisi jawaban saja dan disimpan berdasarkan pasangan akun/percobaan. Sumber kebenaran tetap MySQL.
- Pembatasan login per email membantu menahan percobaan berulang; proteksi penyalahgunaan lintas akun/IP skala besar perlu ditambahkan pada proxy bila situs dibuka luas.
- Penyimpanan gambar dalam JSON membuat implementasi mandiri, tetapi meningkatkan ukuran snapshot/backup. Untuk bank soal besar, gunakan object storage dan referensi immutable.
- Backup di luar VM tetap diperlukan karena volume Docker bukan backup.
