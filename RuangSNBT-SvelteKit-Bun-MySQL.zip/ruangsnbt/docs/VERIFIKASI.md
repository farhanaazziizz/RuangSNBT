# Laporan verifikasi source

## Pemeriksaan yang selesai

| Pemeriksaan | Hasil |
|---|---|
| `svelte-kit sync` + `svelte-check --tsconfig ./tsconfig.json` | 0 error, 0 warning |
| Kompilasi Vite/SvelteKit frontend dan server (`CHECK_BUILD=1`) | Berhasil |
| Tes domain CBT | 9 lulus, 0 gagal |
| SSR halaman login | HTTP 200 dan teks login dirender |
| Halaman utama tanpa sesi | Redirect 303 ke `/login` |
| API bootstrap tanpa sesi | HTTP 401 |
| Mutasi dengan Origin asing | HTTP 403 |
| Sintaks shell backup/restore (`sh -n`) | Berhasil |

Tes domain dijalankan melalui Node 24 dengan transformasi TypeScript karena Bun tidak dapat dieksekusi di lingkungan pembuatan ini. Test memakai `node:test` dan `node:assert`, yang juga dapat dijalankan di Bun. Tidak ada database palsu yang dipakai sebagai bukti kompatibilitas MySQL.

Cakupan domain: kunci/pembahasan tidak bocor selama simulasi, penyimpanan jawaban/ragu-ragu dan serialisasi deadline, snapshot tetap setelah soal diedit, kedaluwarsa beberapa bagian, penolakan jawaban terlambat, penguncian jawaban pertama saat latihan, retry idempoten, penilaian benar/salah/kosong, pengacakan konsisten, percobaan terpisah, serta validasi cadangan/soal/paket.

## Batas verifikasi

- Bun 1.4.2 yang tersedia di lingkungan pembuatan berhenti/crash bahkan pada perintah sederhana sebelum aplikasi dijalankan.
- Karena itu **tahap adapter Bun untuk menghasilkan server produksi belum dijalankan**. `CHECK_BUILD=1` melewati adapter, bukan build produksi. Peringatan `adapter_missing` pada pemeriksaan tersebut memang diharapkan. Build normal menggunakan adapter Bun resmi.
- Docker dan server MySQL tidak tersedia di lingkungan ini. Migrasi, transaksi Bun.SQL, Docker Compose, serta tes integrasi HTTP dengan database nyata **belum dieksekusi**.
- Pemeriksaan visual/interaksi di browser belum dilakukan.
- Kapasitas 50 peserta bersamaan belum diukur.

## Verifikasi wajib pada VM/staging sebelum dipakai peserta

1. Jalankan `docker compose up -d --build`; pastikan tahap check/build Bun lulus, MySQL sehat, dan layanan init exit 0.
2. Jalankan `tests/integration.test.ts` memakai akun pemilik pada database staging yang dapat dibuang. Instruksi variabel ada dalam README.
3. Periksa alur desktop dan ponsel: tambah soal, pratinjau, susun paket, mulai, tandai ragu-ragu, refresh, lanjutkan, submit, pembahasan, ulang, dan kedua riwayat.
4. Putuskan koneksi saat halaman ujian terbuka; pastikan antrean lokal terkirim sebelum deadline dan jawaban terlambat ditolak.
5. Uji 50 akun terpisah untuk mulai/autosave/submit serentak. Skrip `load-test.ts` hanya smoke test baca dan tidak menggantikan simulasi peserta.
6. Uji restore MySQL di database sementara; pastikan akun dan riwayat dapat dipulihkan.

ZIP berisi source, konfigurasi, lockfile npm, dokumentasi dan tes, bukan server produksi yang telah terbukti melalui seluruh pengujian di atas.
