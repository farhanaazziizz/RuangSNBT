import type { Handle } from '@sveltejs/kit/hooks';
import { json } from '@sveltejs/kit';
import { sessionUser, hash } from '#lib/server/auth.ts';
export const handle: Handle = async ({ event, resolve }) => {
  event.locals.user = null;
  if (!['GET', 'HEAD', 'OPTIONS'].includes(event.request.method)) {
    const allowed = process.env.ORIGIN || event.url.origin;
    if (event.request.headers.get('origin') !== allowed)
      return json({ message: 'Asal permintaan tidak diizinkan.' }, { status: 403 });
  }
  if (event.cookies.get('session')) {
    try {
      event.locals.user = await sessionUser(event.cookies.get('session'));
      event.locals.sessionHash = hash(event.cookies.get('session')!);
    } catch (e) {
      console.error('session lookup failed', e);
      return new Response('Layanan data belum tersedia. Silakan coba lagi.', { status: 503 });
    }
  }
  const response = await resolve(event);
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('Referrer-Policy', 'same-origin');
  response.headers.set('X-Frame-Options', 'DENY');
  if (event.url.pathname.startsWith('/api') || event.locals.user)
    response.headers.set('Cache-Control', 'no-store');
  return response;
};
