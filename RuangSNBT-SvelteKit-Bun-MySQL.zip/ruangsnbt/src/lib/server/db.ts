import type { SQL } from 'bun';
let connection: SQL | undefined;
export function db(): SQL {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL belum diatur.');
  return (connection ??= new Bun.SQL(process.env.DATABASE_URL, {
    max: 10,
    idleTimeout: 30,
    connectionTimeout: 10,
  }));
}
export const parseJSON = <T>(value: unknown): T =>
  typeof value === 'string' ? JSON.parse(value) : (value as T);
