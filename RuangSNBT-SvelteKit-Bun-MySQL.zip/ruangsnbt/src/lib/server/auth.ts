import { createHash, randomBytes } from 'node:crypto';
import { db } from './db.ts';
import { AppError } from './validation.ts';
import type { User } from '../types.ts';
export const hash = (s: string) => createHash('sha256').update(s).digest('hex');
export const secureCookie = () => process.env.ORIGIN?.startsWith('https://') ?? false;
export async function sessionUser(token: string | undefined): Promise<User | null> {
  if (!token) return null;
  const rows =
    await db()`SELECT u.id,u.name,u.email,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=${hash(token)} AND s.expires_at>${Date.now()}`;
  return (rows[0] as User) || null;
}
export async function login(
  email: unknown,
  password: unknown,
): Promise<{ token: string; user: User }> {
  if (
    typeof email !== 'string' ||
    typeof password !== 'string' ||
    email.length > 254 ||
    password.length > 128
  )
    throw new AppError(400, 'Email atau kata sandi tidak valid.');
  email = email.trim().toLowerCase();
  const bucket = hash('login:' + email),
    now = Date.now();
  const allowed = await db().begin(async (tx) => {
    await tx`INSERT IGNORE INTO login_limits (bucket,count,reset_at) VALUES (${bucket},0,${now + 900000})`;
    const [r] = await tx`SELECT count,reset_at FROM login_limits WHERE bucket=${bucket} FOR UPDATE`;
    if (Number(r.reset_at) <= now) {
      await tx`UPDATE login_limits SET count=1,reset_at=${now + 900000} WHERE bucket=${bucket}`;
      return true;
    }
    if (r.count >= 10) return false;
    await tx`UPDATE login_limits SET count=count+1 WHERE bucket=${bucket}`;
    return true;
  });
  if (!allowed) throw new AppError(429, 'Terlalu banyak percobaan. Coba lagi dalam 15 menit.');
  const [u] = await db()`SELECT * FROM users WHERE email=${email}`;
  // A dummy Argon2 check equalizes missing-account timing without creating a default password.
  const valid = u
    ? await Bun.password.verify(password, u.password_hash)
    : await Bun.password.verify(password, await dummyHash());
  if (!u || !valid) throw new AppError(401, 'Email atau kata sandi salah.');
  await db()`DELETE FROM login_limits WHERE bucket=${bucket}`;
  await db()`DELETE FROM sessions WHERE expires_at<${now}`;
  const token = randomBytes(32).toString('hex');
  await db()`INSERT INTO sessions (token_hash,user_id,expires_at) VALUES (${hash(token)},${u.id},${now + 7 * 86400000})`;
  return { token, user: { id: u.id, name: u.name, email: u.email, role: u.role } };
}
let dummy: Promise<string> | undefined;
function dummyHash() {
  return (dummy ??= Bun.password.hash(randomBytes(32).toString('hex'), { algorithm: 'argon2id' }));
}
export async function createUser(input: {
  email: string;
  name: string;
  password: string;
  role: 'owner' | 'student';
}): Promise<User> {
  const { name, password, role } = input;
  const email = input.email?.trim().toLowerCase();
  if (
    !email ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
    email.length > 254 ||
    !name?.trim() ||
    name.length > 120 ||
    password?.length < 12 ||
    password?.length > 128 ||
    !['owner', 'student'].includes(role)
  )
    throw new AppError(400, 'Isi nama, email valid, dan kata sandi 12–128 karakter.');
  const u: User = { id: crypto.randomUUID(), name: name.trim(), email, role };
  const encoded = await Bun.password.hash(password, { algorithm: 'argon2id' });
  try {
    await db()`INSERT INTO users (id,email,name,password_hash,role,created_at) VALUES (${u.id},${email},${u.name},${encoded},${role},${Date.now()})`;
  } catch (e) {
    if ((e as { errno?: number }).errno === 1062) throw new AppError(409, 'Email sudah terdaftar.');
    throw e;
  }
  return u;
}
