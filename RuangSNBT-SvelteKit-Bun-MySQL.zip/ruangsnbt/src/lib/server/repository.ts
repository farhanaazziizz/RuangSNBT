import { db, parseJSON } from './db.ts';
import { hash } from './auth.ts';
import { AppError, validateQuestion, validatePackage } from './validation.ts';
import { advanceExpired, createAttempt, publicAttempt, summarize, shuffle } from './domain.ts';
import type {
  Attempt,
  Question,
  ExamPackage,
  User,
  Bootstrap,
  Backup,
  PublicAttempt,
} from '../types.ts';
// Bun transaction handles and the root SQL client share the same tagged-template interface.
type Executor = ReturnType<typeof db>;
export async function questions(tx: Executor = db()): Promise<Question[]> {
  const rows = await tx`SELECT payload FROM questions ORDER BY id`;
  return rows.map((r: { payload: unknown }) => parseJSON<Question>(r.payload));
}
export async function packages(tx: Executor = db()): Promise<ExamPackage[]> {
  const rows =
    await tx`SELECT p.payload,s.payload AS section_data,s.position FROM packages p LEFT JOIN package_sections s ON s.package_id=p.id ORDER BY p.id,s.position`;
  const out = new Map<string, ExamPackage>();
  for (const r of rows) {
    const p = parseJSON<ExamPackage>(r.payload);
    if (!out.has(p.id)) out.set(p.id, { ...p, sections: [] });
    if (r.section_data) out.get(p.id)!.sections.push(parseJSON(r.section_data));
  }
  return [...out.values()];
}
async function putQuestion(tx: Executor, q: Question) {
  const tid = hash(q.section + '\0' + q.topic);
  await tx`INSERT IGNORE INTO topics (id,section,name) VALUES (${tid},${q.section},${q.topic})`;
  await tx`INSERT INTO question_versions (question_id,version,payload) VALUES (${q.id},${q.version},${JSON.stringify(q)}) ON DUPLICATE KEY UPDATE payload=payload`;
  await tx`INSERT INTO questions (id,topic_id,version,status,archived,payload) VALUES (${q.id},${tid},${q.version},${q.status},${q.archived},${JSON.stringify(q)}) ON DUPLICATE KEY UPDATE topic_id=VALUES(topic_id),version=VALUES(version),status=VALUES(status),archived=VALUES(archived),payload=VALUES(payload)`;
}
async function putPackage(tx: Executor, p: ExamPackage) {
  const { sections, ...meta } = p;
  await tx`INSERT INTO packages (id,name,status,payload) VALUES (${p.id},${p.name},${p.status},${JSON.stringify(meta)}) ON DUPLICATE KEY UPDATE name=VALUES(name),status=VALUES(status),payload=VALUES(payload)`;
  await tx`DELETE FROM package_sections WHERE package_id=${p.id}`;
  for (let i = 0; i < sections.length; i++) {
    const s = { ...sections[i], id: crypto.randomUUID() };
    await tx`INSERT INTO package_sections (id,package_id,position,payload) VALUES (${s.id},${p.id},${i},${JSON.stringify(s)})`;
  }
}
export async function saveQuestion(input: unknown) {
  const q = validateQuestion(input);
  return db().begin(async (tx) => {
    const [old] = await tx`SELECT version FROM questions WHERE id=${q.id} FOR UPDATE`;
    if (old && q.version !== old.version)
      throw new AppError(409, 'Soal sudah diubah di tab lain. Muat ulang sebelum menyimpan.');
    q.version = old ? old.version + 1 : 1;
    q.demo = false;
    await putQuestion(tx, q);
    return q;
  });
}
export async function savePackage(input: unknown) {
  return db().begin(async (tx) => {
    const p = validatePackage(input, await questions(tx));
    p.demo = false;
    await putPackage(tx, p);
    return p;
  });
}
async function readAttempt(tx: Executor, id: string, userId: string): Promise<Attempt> {
  const [row] =
    await tx`SELECT snapshot FROM attempts WHERE id=${id} AND user_id=${userId} FOR UPDATE`;
  if (!row) throw new AppError(404, 'Percobaan tidak ditemukan.');
  const a = parseJSON<Attempt>(row.snapshot);
  a.answers = {};
  const rows = await tx`SELECT * FROM answers WHERE attempt_id=${id}`;
  for (const r of rows)
    a.answers[r.question_id] = {
      option: r.option_index,
      flagged: !!r.flagged,
      confirmed: !!r.confirmed,
      revision: r.revision,
    };
  return a;
}
async function writeAttempt(tx: Executor, a: Attempt, dirty: string[] = []) {
  const { answers, ...snapshot } = a;
  await tx`UPDATE attempts SET status=${a.status},ended_at=${a.ended},snapshot=${JSON.stringify(snapshot)},result=${a.result ? JSON.stringify(a.result) : null} WHERE id=${a.id}`;
  for (const [id, v] of Object.entries(answers).filter(([id]) => dirty.includes(id))) {
    await tx`INSERT INTO answers (attempt_id,question_id,option_index,flagged,confirmed,revision,updated_at) VALUES (${a.id},${id},${v.option},${v.flagged},${v.confirmed},${v.revision},${Date.now()}) ON DUPLICATE KEY UPDATE option_index=VALUES(option_index),flagged=VALUES(flagged),confirmed=VALUES(confirmed),revision=VALUES(revision),updated_at=VALUES(updated_at)`;
  }
}
export async function attemptOperation(
  user: User,
  id: string,
  action?: (a: Attempt, now: number) => void,
): Promise<PublicAttempt> {
  const result = await db().begin(async (tx) => {
    const a = await readAttempt(tx, id, user.id),
      now = Date.now();
    const revisions = Object.fromEntries(
      Object.entries(a.answers).map(([id, v]) => [id, v.revision]),
    );
    const expired = advanceExpired(a, now);
    let problem: AppError | undefined;
    try {
      action?.(a, now);
    } catch (e) {
      if (e instanceof AppError) problem = e;
      else throw e;
    }
    if (expired || action)
      await writeAttempt(
        tx,
        a,
        Object.keys(a.answers).filter((id) => a.answers[id].revision !== revisions[id]),
      );
    return { a: publicAttempt(a, now), problem };
  });
  if (result.problem) throw result.problem;
  return result.a;
}
export async function start(
  user: User,
  input: {
    packageId?: string;
    topic?: string;
    section?: string;
    count?: number;
    difficulty?: string;
    minutes?: number;
  },
): Promise<PublicAttempt> {
  return db().begin(async (tx) => {
    await tx`SELECT id FROM users WHERE id=${user.id} FOR UPDATE`;
    const active = await tx`SELECT id FROM attempts WHERE user_id=${user.id} AND status='active'`;
    for (const r of active) {
      const a = await readAttempt(tx, r.id, user.id);
      advanceExpired(a, Date.now());
      await writeAttempt(tx, a);
      if (a.status === 'active') return publicAttempt(a, Date.now());
    }
    const bank = await questions(tx);
    let p: ExamPackage;
    if (input.packageId) {
      const found = (await packages(tx)).find(
        (p) => p.id === input.packageId && p.status === 'ready',
      );
      if (!found) throw new AppError(404, 'Paket siap tidak ditemukan.');
      p = validatePackage(found, bank);
    } else {
      const count = Number(input.count),
        mins = Number(input.minutes);
      const list = bank.filter(
        (q) =>
          q.topic === input.topic &&
          q.section === input.section &&
          q.status === 'ready' &&
          !q.archived &&
          (input.difficulty === 'all' || q.difficulty === input.difficulty),
      );
      if (
        !Number.isInteger(count) ||
        count < 1 ||
        count > list.length ||
        count > 200 ||
        !Number.isInteger(mins) ||
        mins < 0 ||
        mins > 240
      )
        throw new AppError(400, 'Jumlah soal atau durasi latihan tidak valid.');
      const shuffled = shuffle(list).slice(0, count);
      p = {
        id: 'practice',
        name: 'Latihan · ' + input.topic,
        description: '',
        mode: 'latihan',
        status: 'ready',
        demo: shuffled.every((q) => q.demo),
        allowBack: false,
        shuffleOptions: false,
        shuffleQuestions: true,
        sections: [
          {
            id: crypto.randomUUID(),
            name: input.section!,
            duration: mins,
            questionIds: shuffled.map((q) => q.id),
          },
        ],
      };
    }
    const a = createAttempt(p, bank, user.id, Date.now());
    if (!input.packageId) {
      a.packageId = null;
      a.practiceTopic = input.topic;
    }
    const { answers, ...snapshot } = a;
    await tx`INSERT INTO attempts (id,user_id,package_id,status,started_at,snapshot) VALUES (${a.id},${user.id},${a.packageId},'active',${a.started},${JSON.stringify(snapshot)})`;
    return publicAttempt(a, Date.now());
  });
}
export async function bootstrap(user: User): Promise<Bootstrap> {
  const bank = await questions(),
    pkgs = await packages();
  const ids = await db()`SELECT id FROM attempts WHERE user_id=${user.id} ORDER BY started_at DESC`;
  const attempts = [];
  for (const row of ids) {
    const a = await db().begin(async (tx) => {
      const a = await readAttempt(tx, row.id, user.id);
      if (advanceExpired(a, Date.now())) await writeAttempt(tx, a);
      return summarize(a);
    });
    attempts.push(a);
  }
  const map = new Map<string, Bootstrap['topics'][number]>();
  for (const q of bank.filter((q) => q.status === 'ready' && !q.archived)) {
    const key = q.section + '|' + q.topic,
      t = map.get(key) || { topic: q.topic, section: q.section, available: 0, difficulties: {} };
    t.available++;
    t.difficulties[q.difficulty] = (t.difficulties[q.difficulty] || 0) + 1;
    map.set(key, t);
  }
  return {
    user,
    questions: user.role === 'owner' ? bank : [],
    packages: user.role === 'owner' ? pkgs : pkgs.filter((p) => p.status === 'ready'),
    attempts,
    topics: [...map.values()],
  };
}
export async function exportContent(): Promise<Backup> {
  return db().begin(async (tx) => ({
    format: 'ruangsnbt-content' as const,
    version: 2 as const,
    questions: await questions(tx),
    packages: await packages(tx),
    questionVersions: (await tx`SELECT payload FROM question_versions`).map(
      (r: { payload: unknown }) => parseJSON<Question>(r.payload),
    ),
  }));
}
export async function importContent(b: Backup) {
  return db().begin(async (tx) => {
    // Merge by ID. Existing attempts retain their independent, immutable snapshots.
    for (const q0 of b.questions) {
      const q = { ...q0 };
      const [old] = await tx`SELECT version FROM questions WHERE id=${q.id} FOR UPDATE`;
      if (old) q.version = old.version + 1;
      await putQuestion(tx, q);
    }
    for (const q of b.questionVersions)
      await tx`INSERT IGNORE INTO question_versions (question_id,version,payload) VALUES (${q.id},${q.version},${JSON.stringify(q)})`;
    for (const p of b.packages) await putPackage(tx, validatePackage(p, await questions(tx)));
    return { questions: b.questions.length, packages: b.packages.length };
  });
}
export async function seedContent(b: Backup) {
  return db().begin(async (tx) => {
    for (const q of b.questions) {
      const r = await tx`SELECT id FROM questions WHERE id=${q.id}`;
      if (!r.length) await putQuestion(tx, q);
    }
    for (const p of b.packages) {
      const r = await tx`SELECT id FROM packages WHERE id=${p.id}`;
      if (!r.length) await putPackage(tx, p);
    }
  });
}
