import type {
  Attempt,
  AttemptSummary,
  ExamPackage,
  Question,
  PublicAttempt,
  Metrics,
  SnapshotQuestion,
} from '../types.ts';
import { AppError } from './validation.ts';
export const copy = <T>(a: T): T => structuredClone(a);
export function shuffle<T>(input: T[]): T[] {
  const a = [...input];
  for (let i = a.length - 1; i > 0; i--) {
    const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
export function score(
  a: Pick<Attempt, 'answers'>,
  questions: Pick<SnapshotQuestion, 'instanceId' | 'key'>[],
): Metrics {
  let correct = 0,
    wrong = 0,
    empty = 0;
  for (const q of questions) {
    const x = a.answers[q.instanceId]?.option;
    if (x === undefined || x === null) empty++;
    else if (x === q.key) correct++;
    else wrong++;
  }
  return {
    total: questions.length,
    correct,
    wrong,
    empty,
    accuracy: questions.length ? Math.round((correct / questions.length) * 100) : 0,
  };
}
export function createAttempt(
  p: ExamPackage,
  bank: Question[],
  userId: string,
  now: number,
): Attempt {
  const a: Attempt = {
    id: crypto.randomUUID(),
    userId,
    packageId: p.id,
    name: p.name,
    mode: p.mode,
    demo: p.demo,
    allowBack: p.allowBack,
    started: now,
    ended: null,
    elapsed: 0,
    status: 'active',
    sectionIndex: 0,
    answers: {},
    sections: p.sections.map((s) => ({
      id: s.id,
      name: s.name,
      duration: s.duration,
      started: null,
      deadline: null,
      ended: null,
      elapsed: 0,
      questions: (p.shuffleQuestions ? shuffle(s.questionIds) : s.questionIds).map((id) => {
        const original = bank.find((q) => q.id === id);
        if (!original) throw new AppError(400, 'Soal tidak tersedia.');
        const q = { ...copy(original), instanceId: crypto.randomUUID() };
        if (p.shuffleOptions) {
          const order = shuffle(q.options.map((_, i) => i));
          q.options = order.map((i) => original.options[i]);
          q.key = order.indexOf(original.key);
        }
        return q;
      }),
    })),
  };
  a.sections[0].started = now;
  a.sections[0].deadline = a.sections[0].duration ? now + a.sections[0].duration * 60000 : null;
  return a;
}
export function finishSection(a: Attempt, time: number) {
  const s = a.sections[a.sectionIndex];
  if (a.status === 'done' || s.ended !== null) return;
  s.ended = time;
  s.elapsed = Math.max(0, time - (s.started ?? time));
  if (a.sectionIndex < a.sections.length - 1) {
    a.sectionIndex++;
    const n = a.sections[a.sectionIndex];
    n.started = time;
    n.deadline = n.duration ? time + n.duration * 60000 : null;
  } else {
    a.status = 'done';
    a.ended = time;
    a.elapsed = a.sections.reduce((n, s) => n + s.elapsed, 0);
    a.result = score(
      a,
      a.sections.flatMap((s) => s.questions),
    );
  }
}
export function advanceExpired(a: Attempt, now: number) {
  let changed = false;
  while (a.status === 'active') {
    const s = a.sections[a.sectionIndex];
    if (s.deadline === null || now < s.deadline) break;
    finishSection(a, s.deadline);
    changed = true;
  }
  return changed;
}
export function saveAnswer(
  a: Attempt,
  input: {
    questionId: string;
    option: number | null;
    flagged: boolean;
    confirm: boolean;
    revision: number;
  },
  now: number,
) {
  advanceExpired(a, now);
  if (a.status !== 'active') throw new AppError(409, 'Sesi sudah selesai.');
  const si = a.sections.findIndex((s) =>
      s.questions.some((q) => q.instanceId === input.questionId),
    ),
    s = a.sections[si];
  if (
    !s ||
    si > a.sectionIndex ||
    (si < a.sectionIndex && !a.allowBack) ||
    (s.deadline !== null && now >= s.deadline)
  )
    throw new AppError(409, 'Batas waktu bagian ini sudah berakhir.');
  const q = s.questions.find((q) => q.instanceId === input.questionId)!;
  if (
    input.option !== null &&
    (!Number.isInteger(input.option) || input.option < 0 || input.option >= q.options.length)
  )
    throw new AppError(400, 'Pilihan jawaban tidak valid.');
  if (
    !Number.isInteger(input.revision) ||
    input.revision < 1 ||
    typeof input.flagged !== 'boolean' ||
    typeof input.confirm !== 'boolean'
  )
    throw new AppError(400, 'Perubahan jawaban tidak valid.');
  const old = a.answers[q.instanceId];
  if (old && input.revision <= old.revision) return;
  if (old?.confirmed && input.option !== old.option)
    throw new AppError(409, 'Jawaban latihan pertama sudah dikonfirmasi.');
  if (input.confirm && (a.mode !== 'latihan' || input.option === null))
    throw new AppError(400, 'Pilih jawaban sebelum memeriksa.');
  a.answers[q.instanceId] = {
    option: input.option,
    flagged: input.flagged,
    confirmed: !!old?.confirmed || input.confirm,
    revision: input.revision,
  };
}
export function publicAttempt(a: Attempt, now: number): PublicAttempt {
  const result = copy(a) as unknown as PublicAttempt;
  result.sections = result.sections.map((s) => ({
    ...s,
    questions: s.questions.map((q) => {
      const allowed =
        a.status === 'done' || (a.mode === 'latihan' && a.answers[q.instanceId]?.confirmed);
      const { key, explanation, source, ...rest } = q as SnapshotQuestion;
      return allowed ? { ...rest, key, explanation } : rest;
    }),
  }));
  result.serverNow = now;
  return result;
}
export function summarize(a: Attempt): AttemptSummary {
  const { sections, answers, ...rest } = a;
  const map = new Map<string, { topic: string; section: string; n: number; correct: number }>();
  if (a.status === 'done')
    for (const q of sections.flatMap((s) => s.questions)) {
      const k = q.section + '|' + q.topic;
      const t = map.get(k) || { topic: q.topic, section: q.section, n: 0, correct: 0 };
      t.n++;
      if (answers[q.instanceId]?.option === q.key) t.correct++;
      map.set(k, t);
    }
  return {
    ...rest,
    total: sections.reduce((n, s) => n + s.questions.length, 0),
    topics: [...map.values()],
  };
}
