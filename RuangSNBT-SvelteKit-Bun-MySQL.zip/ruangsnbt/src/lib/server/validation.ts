import type { Question, ExamPackage, Backup } from '../types.ts';
import { SECTIONS } from '../types.ts';
export class AppError extends Error {
  constructor(
    public status: number,
    message: string,
    public fields: Record<string, string> = {},
  ) {
    super(message);
  }
}
export function assert(condition: unknown, message: string, status = 400): asserts condition {
  if (!condition) throw new AppError(status, message);
}
const str = (s: unknown, max = 200) =>
  typeof s === 'string' && s.trim().length > 0 && s.length <= max;
const id = (s: unknown) => typeof s === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(s);
export function validateQuestion(input: unknown): Question {
  const q = input as Question,
    e: Record<string, string> = {};
  if (!q || typeof q !== 'object') throw new AppError(400, 'Soal tidak valid.');
  if (!str(q.text, 20000)) e.text = 'Teks soal wajib diisi (maks. 20.000 karakter).';
  if (!str(q.topic, 120)) e.topic = 'Topik wajib diisi (maks. 120 karakter).';
  if (!SECTIONS.includes(q.section as (typeof SECTIONS)[number]))
    e.section = 'Pilih bagian tes yang valid.';
  if (q.type !== 'single') e.type = 'Versi ini mendukung pilihan ganda satu jawaban.';
  if (
    !Array.isArray(q.options) ||
    q.options.length < 2 ||
    q.options.length > 8 ||
    q.options.some((o) => !str(o, 4000))
  )
    e.options = 'Isi 2–8 pilihan jawaban, maksimal 4.000 karakter per pilihan.';
  if (!Number.isInteger(q.key) || q.key < 0 || q.key >= q.options?.length)
    e.key = 'Kunci harus menunjuk opsi yang tersedia.';
  if (!['draft', 'ready'].includes(q.status)) e.status = 'Status tidak valid.';
  if (
    typeof q.explanation !== 'string' ||
    q.explanation.length > 20000 ||
    (q.status === 'ready' && !q.explanation.trim())
  )
    e.explanation = 'Soal siap digunakan wajib memiliki pembahasan (maks. 20.000 karakter).';
  if (!['Mudah', 'Sedang', 'Sulit'].includes(q.difficulty))
    e.difficulty = 'Pilih kesulitan editorial.';
  if (
    typeof q.image !== 'string' ||
    q.image.length > 850000 ||
    (q.image && !/^data:image\/(png|jpeg|webp);base64,[a-zA-Z0-9+/=]+$/.test(q.image))
  )
    e.image = 'Gunakan gambar PNG, JPEG, atau WebP maksimal 600 KB.';
  if (typeof q.alt !== 'string' || q.alt.length > 1000 || (q.image && !q.alt.trim()))
    e.alt = 'Gambar memerlukan teks alternatif.';
  if (typeof q.table !== 'string' || q.table.length > 20000) e.table = 'Tabel terlalu panjang.';
  if (typeof q.source !== 'string' || q.source.length > 2000)
    e.source = 'Catatan sumber terlalu panjang.';
  if (Object.keys(e).length) throw new AppError(400, 'Periksa isian soal.', e);
  return {
    ...q,
    id: id(q.id) ? q.id : crypto.randomUUID(),
    version: Number.isInteger(q.version) && q.version > 0 ? q.version : 1,
    demo: !!q.demo,
    archived: !!q.archived,
  };
}
export function validatePackage(input: unknown, questions: Question[]): ExamPackage {
  const p = input as ExamPackage,
    e: Record<string, string> = {};
  if (!p || typeof p !== 'object') throw new AppError(400, 'Paket tidak valid.');
  if (!str(p.name, 200)) e.name = 'Nama paket wajib diisi (maks. 200 karakter).';
  if (typeof p.description !== 'string' || p.description.length > 4000)
    e.description = 'Deskripsi maksimal 4.000 karakter.';
  if (!['simulasi', 'latihan'].includes(p.mode) || !['draft', 'ready'].includes(p.status))
    e.mode = 'Mode atau status tidak valid.';
  if (!Array.isArray(p.sections) || !p.sections.length || p.sections.length > 20)
    e.sections = 'Paket harus memiliki 1–20 bagian.';
  else
    p.sections.forEach((s, i) => {
      if (
        !SECTIONS.includes(s.name as (typeof SECTIONS)[number]) ||
        !Number.isInteger(s.duration) ||
        s.duration < 1 ||
        s.duration > 240 ||
        !Array.isArray(s.questionIds) ||
        s.questionIds.length > 200 ||
        new Set(s.questionIds).size !== s.questionIds.length ||
        s.questionIds.some(
          (qid) =>
            !questions.some(
              (q) =>
                q.id === qid &&
                q.section === s.name &&
                (p.status === 'draft' || (q.status === 'ready' && !q.archived)),
            ),
        ) ||
        (p.status === 'ready' && !s.questionIds.length)
      )
        e['section' + i] =
          'Pilih soal yang sesuai dan durasi 1–240 menit. Paket siap harus memiliki soal siap digunakan.';
    });
  if (Object.keys(e).length) throw new AppError(400, 'Periksa isian paket.', e);
  return {
    ...p,
    id: id(p.id) ? p.id : crypto.randomUUID(),
    allowBack: !!p.allowBack,
    shuffleOptions: !!p.shuffleOptions,
    shuffleQuestions: !!p.shuffleQuestions,
    demo: !!p.demo,
    sections: p.sections.map((s) => ({ ...s, id: id(s.id) ? s.id : crypto.randomUUID() })),
  };
}
export function validateBackup(input: unknown): Backup {
  const b = input as Backup;
  assert(b?.format === 'ruangsnbt-content' && b.version === 2, 'Format cadangan tidak dikenali.');
  assert(
    Array.isArray(b.questions) &&
      b.questions.length <= 5000 &&
      Array.isArray(b.packages) &&
      b.packages.length <= 500 &&
      Array.isArray(b.questionVersions) &&
      b.questionVersions.length <= 10000,
    'Isi cadangan terlalu besar atau tidak valid.',
  );
  b.questions = b.questions.map(validateQuestion);
  b.questionVersions = b.questionVersions.map(validateQuestion);
  b.packages = b.packages.map((p) => validatePackage(p, b.questions));
  assert(
    new Set(b.questions.map((q) => q.id)).size === b.questions.length &&
      new Set(b.packages.map((p) => p.id)).size === b.packages.length,
    'ID cadangan tidak boleh duplikat.',
  );
  return b;
}
