<script lang="ts">
  import { onMount } from 'svelte';
  import type { PublicAttempt } from '#lib/types.ts';
  import { api, ApiError, timer } from '#lib/client.ts';
  import QuestionBody from './QuestionBody.svelte';
  import Modal from './Modal.svelte';
  import Icon from './Icon.svelte';
  export let attempt: PublicAttempt;
  export let exit: () => void;
  export let completed: (a: PublicAttempt) => void;
  type Change = {
    questionId: string;
    option: number | null;
    flagged: boolean;
    confirm: boolean;
    revision: number;
  };
  let a = structuredClone(attempt),
    sectionIndex = a.sectionIndex,
    index = 0,
    showNav = false,
    confirm = false,
    busy = false,
    saving = false,
    message = '',
    online = true,
    now = Date.now(),
    offset = a.serverNow - Date.now(),
    pending: Record<string, Change> = {},
    localError = false,
    refreshing = false;
  const storageKey = 'ruangsnbt:pending:' + a.userId + ':' + a.id;
  $: section = a.sections[sectionIndex];
  $: q = section.questions[index] || section.questions[0];
  $: answer = pending[q.instanceId] || a.answers[q.instanceId];
  $: selected = answer?.option ?? null;
  $: confirmed = a.answers[q.instanceId]?.confirmed || false;
  $: locked =
    a.status === 'done' ||
    (sectionIndex < a.sectionIndex && !a.allowBack) ||
    (section.deadline !== null && now + offset >= section.deadline);
  $: outstanding = Object.keys(pending).length;
  function cache() {
    try {
      localStorage.setItem(storageKey, JSON.stringify(pending));
      localError = false;
    } catch {
      localError = true;
      message =
        'Antrean lokal gagal disimpan. Tetap buka halaman sampai jawaban tersimpan di server.';
    }
  }
  function apply(server: PublicAttempt) {
    const previous = a.sectionIndex;
    offset = server.serverNow - Date.now();
    a = server;
    if (a.sectionIndex !== previous) {
      sectionIndex = a.sectionIndex;
      index = 0;
    }
    if (sectionIndex > a.sectionIndex) sectionIndex = a.sectionIndex;
    if (a.status === 'done') {
      if (!Object.keys(pending).length) localStorage.removeItem(storageKey);
      completed(a);
    }
  }
  function change(option: number | null, flagged: boolean, check = false) {
    if (locked) return;
    const old = pending[q.instanceId] || a.answers[q.instanceId];
    pending = {
      ...pending,
      [q.instanceId]: {
        questionId: q.instanceId,
        option,
        flagged,
        confirm: check || !!pending[q.instanceId]?.confirm,
        revision: (old?.revision || 0) + 1,
      },
    };
    cache();
    void flush();
  }
  async function flush() {
    if (saving || !navigator.onLine) return;
    saving = true;
    try {
      while (Object.keys(pending).length) {
        const value = Object.values(pending)[0];
        try {
          const server = await api<PublicAttempt>('attempts/' + a.id + '/answers', 'PUT', value);
          if (pending[value.questionId]?.revision === value.revision) {
            delete pending[value.questionId];
            pending = { ...pending };
            cache();
          }
          apply(server);
        } catch (e) {
          if (e instanceof ApiError && e.status === 409) {
            delete pending[value.questionId];
            pending = { ...pending };
            cache();
            message = e.message + ' Perubahan yang terlambat tidak dihitung.';
            continue;
          }
          message = e instanceof Error ? e.message : 'Belum tersinkron. Coba lagi.';
          break;
        }
      }
    } finally {
      saving = false;
    }
  }
  async function sync() {
    if (refreshing || saving || !navigator.onLine) return;
    refreshing = true;
    try {
      await flush();
      if (!Object.keys(pending).length) apply(await api<PublicAttempt>('attempts/' + a.id));
    } catch (e) {
      message = e instanceof Error ? e.message : 'Belum tersinkron.';
    } finally {
      refreshing = false;
    }
  }
  async function submit() {
    if (busy) return;
    busy = true;
    message = '';
    try {
      await flush();
      if (!navigator.onLine || Object.keys(pending).length)
        throw Error('Jawaban belum tersinkron. Sambungkan kembali dan coba kirim lagi.');
      const result = await api<PublicAttempt>('attempts/' + a.id + '/submit', 'POST', {
        sectionIndex: a.sectionIndex,
      });
      apply(result);
      sectionIndex = result.sectionIndex;
      index = 0;
      confirm = false;
    } catch (e) {
      message = e instanceof Error ? e.message : 'Pengiriman gagal.';
    } finally {
      busy = false;
    }
  }
  function check() {
    if (selected === null) {
      message = 'Pilih jawaban terlebih dahulu.';
      return;
    }
    change(selected, answer?.flagged || false, true);
  }
  onMount(() => {
    online = navigator.onLine;
    try {
      pending = JSON.parse(localStorage.getItem(storageKey) || '{}');
    } catch {
      pending = {};
      message = 'Antrean lokal rusak. Jawaban yang sudah tersimpan tetap tersedia di server.';
    }
    void flush();
    const connection = () => {
      online = navigator.onLine;
      if (online) void sync();
    };
    window.addEventListener('online', connection);
    window.addEventListener('offline', connection);
    const interval = setInterval(() => {
      now = Date.now();
      const current = a.sections[a.sectionIndex];
      if (current.deadline !== null && now + offset >= current.deadline) void sync();
    }, 1000);
    const poll = setInterval(() => void sync(), 15000);
    return () => {
      clearInterval(interval);
      clearInterval(poll);
      window.removeEventListener('online', connection);
      window.removeEventListener('offline', connection);
    };
  });
</script>

<header class="exam-header">
  <div>
    <h3>
      {a.name}{#if a.demo}<span class="badge demo">Paket Demo</span>{/if}
    </h3>
    <span class="muted small">{section.name} · Bagian {sectionIndex + 1}/{a.sections.length}</span>
  </div>
  <div class="actions">
    <div>
      <div class="timer">
        {section.deadline === null ? 'Tanpa timer' : timer(section.deadline - now - offset)}
      </div>
      <span class="small muted" aria-live="polite"
        >{saving
          ? 'Menyimpan…'
          : outstanding
            ? localError
              ? 'Belum tersimpan lokal'
              : 'Belum tersinkron · ' + outstanding + ' perubahan'
            : online
              ? 'Tersimpan di server'
              : 'Offline · jawaban tersimpan'}</span
      >
    </div>
    <button class="primary" on:click={() => (confirm = true)} disabled={busy}
      >{a.sectionIndex === a.sections.length - 1 ? 'Selesaikan Tryout' : 'Akhiri Bagian'}</button
    >
  </div>
</header>
<div class="exam-body">
  <section class="card">
    {#if message}<div class="notice warning" role="alert">
        {message}<button class="link" on:click={sync}>Coba Lagi</button>
      </div>{/if}{#if !online}<div class="notice warning">
        Koneksi terputus. Perubahan disimpan di perangkat untuk dikirim kembali. Timer tetap
        berjalan; server menolak jawaban yang tiba setelah batas waktu.
      </div>{/if}{#if locked}<div class="notice">
        Waktu bagian ini telah berakhir. {online
          ? 'Menunggu pembaruan server.'
          : 'Sambungkan kembali untuk melihat hasil.'}
      </div>{/if}
    <div class="section-head">
      <span class="badge">Soal {index + 1} dari {section.questions.length}</span><span
        class="small muted">{q.topic}{q.demo ? ' · Demo' : ''}</span
      >
    </div>
    <QuestionBody text={q.text} image={q.image} alt={q.alt} table={q.table} />
    <div class="options">
      {#each q.options as option, i}<button
          class="option"
          class:selected={selected === i}
          class:correct={confirmed && q.key === i}
          class:wrong={confirmed && selected === i && q.key !== i}
          disabled={locked || confirmed || !!pending[q.instanceId]?.confirm}
          on:click={() => change(i, answer?.flagged || false)}
          ><span class="option-letter">{String.fromCharCode(65 + i)}</span><span
            >{option}{confirmed && q.key === i ? ' · Jawaban benar' : ''}</span
          ></button
        >{/each}
    </div>
    {#if a.mode === 'latihan'}{#if confirmed}<div class="explanation">
          <strong>{selected === q.key ? 'Jawabanmu benar' : 'Jawabanmu belum tepat'}</strong><br
          />{q.explanation}
        </div>{:else}<button
          class="primary"
          on:click={check}
          disabled={selected === null || locked || saving || !online}>Periksa Jawaban</button
        >{/if}{/if}
    <div class="qfooter">
      <button disabled={index === 0} on:click={() => index--}>Sebelumnya</button><button
        class:flagged={answer?.flagged}
        disabled={locked}
        on:click={() => change(selected, !answer?.flagged)}
        ><Icon name="flag" />{answer?.flagged ? 'Ditandai' : 'Ragu-ragu'}</button
      ><button
        class="primary"
        on:click={() => (index < section.questions.length - 1 ? index++ : (confirm = true))}
        >{index < section.questions.length - 1 ? 'Berikutnya' : 'Selesai Bagian'}</button
      >
    </div>
    <div class="actions" style="margin-top:16px">
      <button class="mobile-only" on:click={() => (showNav = !showNav)}>Daftar Soal</button><button
        class="link"
        on:click={exit}>Simpan & Keluar</button
      >{#if outstanding}<span class="small muted"
          >Antrean lokal akan dilanjutkan saat sesi dibuka kembali.</span
        >{/if}
    </div>
  </section>
  <aside class="card exam-aside" class:show={showNav}>
    <h2>Navigasi soal</h2>
    <p class="muted small">Pilih nomor untuk berpindah.</p>
    <div class="question-nav">
      {#each section.questions as question, i}{@const ans =
          pending[question.instanceId] || a.answers[question.instanceId]}<button
          class="qnum"
          class:current={i === index}
          class:answered={ans?.option !== null && ans?.option !== undefined}
          class:flagged={ans?.flagged}
          aria-label={'Soal ' +
            (i + 1) +
            (ans?.flagged ? ', ragu-ragu' : ans?.option != null ? ', sudah dijawab' : '')}
          on:click={() => (index = i)}
          >{i + 1}{ans?.flagged ? ' ⚑' : ans?.option != null ? ' ✓' : ''}</button
        >{/each}
    </div>
    <div class="legend">
      <span>□ Belum dijawab</span><span>✓ Sudah dijawab</span><span>⚑ Ragu-ragu</span><span
        >Outline navy: soal aktif</span
      >
    </div>
    {#if a.allowBack}<div class="field" style="margin-top:24px">
        <label for="section-nav">Tinjau bagian</label><select
          id="section-nav"
          bind:value={sectionIndex}
          on:change={() => (index = 0)}
          >{#each a.sections.slice(0, a.sectionIndex + 1) as s, i}<option value={i}>{s.name}</option
            >{/each}</select
        >
      </div>{/if}
    <div class="focus-note">
      {a.mode === 'simulasi'
        ? 'Kunci dan pembahasan tersedia setelah seluruh sesi selesai.'
        : 'Jawaban pertama yang diperiksa menjadi dasar hasil.'}
    </div>
  </aside>
</div>
{#if confirm}<Modal
    title={a.sectionIndex === a.sections.length - 1 ? 'Selesaikan sesi ini?' : 'Akhiri bagian ini?'}
    close={() => (confirm = false)}
    >{@const current = a.sections[a.sectionIndex]}{@const answered = current.questions.filter(
      (q) => (pending[q.instanceId] || a.answers[q.instanceId])?.option != null,
    ).length}
    <p>Bagian: {current.name}</p>
    <div class="stats" style="grid-template-columns:repeat(3,1fr)">
      <div class="card stat">
        Terjawab
        <div class="stat-value">{answered}</div>
      </div>
      <div class="card stat">
        Kosong
        <div class="stat-value">{current.questions.length - answered}</div>
      </div>
      <div class="card stat">
        Ragu-ragu
        <div class="stat-value">
          {current.questions.filter(
            (q) => (pending[q.instanceId] || a.answers[q.instanceId])?.flagged,
          ).length}
        </div>
      </div>
    </div>
    <p class="muted">
      Jawaban dikirim sebelum bagian difinalisasi. Bagian berikutnya dimulai segera setelah
      pengiriman berhasil.
    </p>
    {#if message}<p class="error-text">{message}</p>{/if}
    <div class="actions">
      <button on:click={() => (confirm = false)} disabled={busy}>Kembali Mengerjakan</button><button
        class="primary"
        on:click={submit}
        disabled={busy}>{busy ? 'Mengirim…' : 'Kirim Jawaban'}</button
      >
    </div></Modal
  >{/if}
