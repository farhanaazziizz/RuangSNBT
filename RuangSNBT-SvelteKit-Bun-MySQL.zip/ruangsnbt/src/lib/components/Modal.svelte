<script lang="ts">
  import { onMount } from 'svelte';
  export let title: string;
  export let close: () => void;
  export let wide = false;
  let dialog: HTMLDialogElement;
  onMount(() => {
    dialog.showModal();
    return () => dialog.close();
  });
</script>

<dialog bind:this={dialog} class:wide class="modal native-modal" on:cancel|preventDefault={close}>
  <div class="section-head">
    <h2>{title}</h2>
    <button class="close" aria-label="Tutup" on:click={close}>×</button>
  </div>
  <slot />
</dialog>
