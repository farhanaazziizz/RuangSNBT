<script lang="ts">
  import type { PublicAttempt, PublicQuestion } from '#lib/types.ts';
  import { date, duration } from '#lib/client.ts';
  import QuestionBody from './QuestionBody.svelte';
  export let a: PublicAttempt;
  export let retry: () => void;
  export let practice: (topic: string, section: string) => void;
  export let history: () => void;
  let filter = 'all';
  $: questions = a.sections.flatMap((s) => s.questions);
  const status = (q: PublicQuestion) =>
    a.answers[q.instanceId]?.option == null
      ? 'empty'
      : a.answers[q.instanceId]?.option === q.key
        ? 'correct'
        : 'wrong';
  function metrics(qs: PublicQuestion[]) {
    const correct = qs.filter((q) => status(q) === 'correct').length,
      empty = qs.filter((q) => status(q) === 'empty').length;
    return {
      correct,
      empty,
      wrong: qs.length - correct - empty,
      accuracy: Math.round((correct / qs.length) * 100),
    };
  }
  $: m = metrics(questions);
  $: topics = Array.from(new Set(questions.map((q) => q.section + '|' + q.topic))).map((key) => {
    const list = questions.filter((q) => q.section + '|' + q.topic === key);
    return { name: list[0].topic, section: list[0].section, n: list.length, ...metrics(list) };
  });
</script>

<div class="page-title">
  <div>
    <h1>Hasil latihanmu</h1>
    <span class="muted">{a.name} · {date(a.ended!)}</span>
  </div>
  <span class="badge good">✓ Selesai</span>
</div>
<div class="notice">
  Hasil latihan internal · Akurasi ini bukan skor resmi UTBK/SNBT.{a.demo ? ' · Paket Demo' : ''}
</div>
<div class="stats">
  {#each [['Akurasi', m.accuracy + '%'], ['Benar', m.correct], ['Salah / kosong', m.wrong + ' / ' + m.empty], ['Waktu', duration(a.elapsed)]] as stat}<div
      class="card stat"
    >
      <span class="muted">{stat[0]}</span>
      <div class="stat-value">{stat[1]}</div>
    </div>{/each}
</div>
<section class="card">
  <h2>Ringkasan per bagian</h2>
  <div class="table-wrap">
    <table class="desktop-table">
      <thead
        ><tr
          ><th>Bagian</th><th>Soal</th><th>Benar</th><th>Salah</th><th>Kosong</th><th>Akurasi</th
          ><th>Waktu</th></tr
        ></thead
      ><tbody
        >{#each a.sections as s}{@const sm = metrics(s.questions)}<tr
            ><td>{s.name}</td><td data-label="Soal">{s.questions.length}</td><td data-label="Benar"
              >{sm.correct}</td
            ><td data-label="Salah">{sm.wrong}</td><td data-label="Kosong">{sm.empty}</td><td
              data-label="Akurasi">{sm.accuracy}%</td
            ><td data-label="Waktu">{duration(s.elapsed)}</td></tr
          >{/each}</tbody
      >
    </table>
  </div>
</section>
<section class="card" style="margin:24px 0">
  <h2>Evaluasi topik</h2>
  <div class="topics">
    {#each topics as t}<div class="review">
        <h3>{t.name}</h3>
        <p class="muted">{t.correct} benar dari {t.n} soal · {t.accuracy}%</p>
        <span
          class="badge"
          class:good={t.n >= 3 && t.accuracy >= 70}
          class:amber={t.n >= 3 && t.accuracy < 70}
          >{t.n < 3
            ? 'Data masih sedikit'
            : t.accuracy >= 70
              ? 'Relatif kuat'
              : 'Perlu dilatih'}</span
        ><br /><button class="link" on:click={() => practice(t.name, t.section)}
          >Latih Topik Ini</button
        >
      </div>{/each}
  </div>
</section>
<div class="section-head">
  <h2>Pembahasan soal</h2>
  <select style="width:160px" aria-label="Filter pembahasan" bind:value={filter}
    ><option value="all">Semua</option><option value="correct">Benar</option><option value="wrong"
      >Salah</option
    ><option value="empty">Kosong</option></select
  >
</div>
{#each questions.filter((q) => filter === 'all' || status(q) === filter) as q}<article
    class="card"
    style="margin-bottom:16px"
  >
    <div class="section-head">
      <h3>{q.topic}</h3>
      <span class="badge" class:good={status(q) === 'correct'}
        >{status(q) === 'correct' ? 'Benar' : status(q) === 'wrong' ? 'Salah' : 'Kosong'}{q.demo
          ? ' · Demo'
          : ''}</span
      >
    </div>
    <QuestionBody text={q.text} image={q.image} alt={q.alt} table={q.table} />
    <p>
      <strong>Jawaban Anda:</strong>
      {a.answers[q.instanceId]?.option == null
        ? 'Tidak dijawab'
        : q.options[a.answers[q.instanceId].option!]}
    </p>
    <p><strong>Jawaban benar:</strong> {q.options[q.key!]}</p>
    <div class="explanation"><strong>Pembahasan</strong><br />{q.explanation}</div>
    <button class="link" on:click={() => practice(q.topic, q.section)}>Latih Topik Ini</button>
  </article>{:else}<div class="card empty">Tidak ada soal pada filter ini.</div>{/each}
<div class="actions">
  <button class="primary" on:click={retry}
    >{a.practiceTopic ? 'Latihan Lagi' : 'Kerjakan Ulang'}</button
  ><button on:click={history}>Lihat Riwayat</button>
</div>
