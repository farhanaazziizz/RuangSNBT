<script lang="ts">
  import type { Question } from '#lib/types.ts';
  import { SECTIONS } from '#lib/types.ts';
  import { api, ApiError } from '#lib/client.ts';
  import Modal from './Modal.svelte';
  import QuestionBody from './QuestionBody.svelte';
  export let initial: Question | null = null;
  export let close: () => void;
  export let saved: () => void;
  let q: Question = initial
    ? structuredClone(initial)
    : {
        id: crypto.randomUUID(),
        version: 1,
        section: SECTIONS[0],
        topic: '',
        type: 'single',
        text: '',
        options: ['', '', '', ''],
        key: 0,
        explanation: '',
        difficulty: 'Sedang',
        status: 'draft',
        demo: false,
        archived: false,
        image: '',
        alt: '',
        table: '',
        source: '',
      };
  let busy = false,
    preview = false,
    message = '',
    errors: Record<string, string> = {};
  async function save() {
    busy = true;
    message = '';
    errors = {};
    try {
      await api('questions', 'POST', q);
      saved();
    } catch (e) {
      message = e instanceof Error ? e.message : 'Gagal menyimpan.';
      if (e instanceof ApiError) errors = e.fields;
    } finally {
      busy = false;
    }
  }
  async function imageFile(event: Event) {
    const file = (event.currentTarget as HTMLInputElement).files?.[0];
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 600000) {
      message = 'Gunakan PNG, JPEG atau WebP maksimal 600 KB.';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => (q.image = String(reader.result));
    reader.readAsDataURL(file);
  }
</script>

<Modal title={initial ? 'Edit soal' : 'Tambah soal'} {close} wide
  ><form on:submit|preventDefault={save}>
    <div class="form-grid">
      <div class="field">
        <label for="section">Bagian tes</label><select id="section" bind:value={q.section}
          >{#each SECTIONS as s}<option>{s}</option>{/each}</select
        ><span class="error-text">{errors.section || ''}</span>
      </div>
      <div class="field">
        <label for="topic">Topik</label><input
          id="topic"
          bind:value={q.topic}
          required
          maxlength="120"
        /><span class="error-text">{errors.topic || ''}</span>
      </div>
      <div class="full field">
        <label for="qtext">Teks soal / stimulus</label><textarea
          id="qtext"
          bind:value={q.text}
          required
          maxlength="20000"
        ></textarea><small>Rumus dapat ditulis dengan simbol Unicode: x², √, ≤, atau a/b.</small
        ><span class="error-text">{errors.text || ''}</span>
      </div>
      <div class="full field">
        <label for="qtable">Tabel opsional</label><textarea id="qtable" bind:value={q.table}
        ></textarea><small
          >Pisahkan kolom dengan |, baris dengan Enter. Baris pertama adalah judul kolom.</small
        ><span class="error-text">{errors.table || ''}</span>
      </div>
      <div class="field">
        <label for="image">Gambar opsional</label><input
          id="image"
          type="file"
          accept="image/png,image/jpeg,image/webp"
          on:change={imageFile}
        /><span class="error-text">{errors.image || ''}</span>{#if q.image}<button
            class="link"
            type="button"
            on:click={() => (q.image = '')}>Hapus Gambar</button
          >{/if}
      </div>
      <div class="field">
        <label for="alt">Teks alternatif gambar</label><input
          id="alt"
          bind:value={q.alt}
          required={!!q.image}
        /><span class="error-text">{errors.alt || ''}</span>
      </div>
      {#each q.options as option, i}<div class="field">
          <label for={'option' + i}>Pilihan {String.fromCharCode(65 + i)}</label><input
            id={'option' + i}
            bind:value={q.options[i]}
            required
            maxlength="4000"
          />
        </div>{/each}
      <div class="full error-text">{errors.options || ''}</div>
      <div class="field">
        <label for="key">Kunci jawaban</label><select id="key" bind:value={q.key}
          >{#each q.options as _, i}<option value={i}>{String.fromCharCode(65 + i)}</option
            >{/each}</select
        ><span class="error-text">{errors.key || ''}</span>
      </div>
      <div class="field">
        <label for="difficulty">Kesulitan editorial</label><select
          id="difficulty"
          bind:value={q.difficulty}
          ><option>Mudah</option><option>Sedang</option><option>Sulit</option></select
        >
      </div>
      <div class="full field">
        <label for="explanation">Pembahasan</label><textarea
          id="explanation"
          bind:value={q.explanation}
          required={q.status === 'ready'}
        ></textarea><span class="error-text">{errors.explanation || ''}</span>
      </div>
      <div class="field">
        <label for="status">Status</label><select id="status" bind:value={q.status}
          ><option value="draft">Draft</option><option value="ready">Siap Digunakan</option></select
        >
      </div>
      <div class="field">
        <label for="source">Catatan sumber (opsional)</label><input
          id="source"
          bind:value={q.source}
        />
      </div>
    </div>
    {#if preview}<div class="review">
        <h3>Pratinjau soal</h3>
        <QuestionBody
          text={q.text}
          image={q.image}
          alt={q.alt}
          table={q.table}
        />{#each q.options as option, i}<p>
            {String.fromCharCode(65 + i)}. {option}
            {i === q.key ? '✓ Kunci' : ''}
          </p>{/each}
        <div class="explanation">{q.explanation}</div>
      </div>{/if}{#if message}<div class="notice warning" role="alert">{message}</div>{/if}
    <div class="actions">
      <button type="button" on:click={() => (preview = !preview)}>Pratinjau</button><button
        class="primary"
        disabled={busy}>{busy ? 'Menyimpan…' : 'Simpan Soal'}</button
      >
    </div>
  </form></Modal
>
