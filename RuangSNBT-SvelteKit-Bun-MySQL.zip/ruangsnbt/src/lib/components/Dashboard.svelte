<script lang="ts">
  import type { Bootstrap, ExamPackage, AttemptSummary } from '#lib/types.ts';
  import Icon from './Icon.svelte';
  import PackageCard from './PackageCard.svelte';
  import { date } from '#lib/client.ts';
  export let data: Bootstrap;
  export let go: (v: string) => void;
  export let open: (p: ExamPackage) => void;
  export let resume: (id: string) => void;
  export let practice: (t: string, s: string) => void;
  $: done = data.attempts.filter((a) => a.status === 'done');
  $: active = data.attempts.find((a) => a.status === 'active');
  $: total = done.reduce((n, a) => n + a.total, 0);
  $: correct = done.reduce((n, a) => n + (a.result?.correct || 0), 0);
  function focus() {
    const map = new Map<string, { topic: string; section: string; n: number; correct: number }>();
    for (const a of done)
      for (const t of a.topics) {
        const k = t.section + '|' + t.topic,
          v = map.get(k) || { topic: t.topic, section: t.section, n: 0, correct: 0 };
        v.n += t.n;
        v.correct += t.correct;
        map.set(k, v);
      }
    return [...map.values()]
      .filter((t) => t.n >= 3 && t.correct / t.n < 0.7)
      .sort((a, b) => a.correct / a.n - b.correct / b.n);
  }
  $: low = focus();
  $: stats = [
    [
      'Tryout selesai',
      done.filter((a) => a.mode === 'simulasi').length,
      'Sesi simulasi diselesaikan',
      'check',
    ],
    [
      'Akurasi jawaban',
      total ? Math.round((correct / total) * 100) + '%' : '—',
      total ? 'Dari ' + total + ' soal' : 'Belum ada sesi selesai',
      'target',
    ],
    [
      'Waktu belajar',
      done.length ? Math.floor(done.reduce((n, a) => n + a.elapsed, 0) / 60000) + ' menit' : '—',
      'Durasi sesi yang selesai',
      'clock',
    ],
    ['Perlu dilatih', low.length || '—', 'Minimal 3 soal per topik', 'chart'],
  ];
  function chartGroups() {
    const g = new Map<string, AttemptSummary[]>();
    for (const a of [...done].reverse()) {
      const key = a.packageId || a.name;
      g.set(key, [...(g.get(key) || []), a]);
    }
    return [...g.values()].filter((a) => a.length >= 2).map((g) => g.slice(-8));
  }
  $: groups = chartGroups();
</script>

<div class="page-title">
  <div>
    <h1>Ruang belajarmu</h1>
    <div class="muted">Lanjutkan latihan dan lihat perkembanganmu.</div>
  </div>
  <span class="date-pill">{date(Date.now())}</span>
</div>
<section class="card hero">
  <div>
    <div class="eyebrow">SELANGKAH LEBIH SIAP</div>
    <h2>Siap latihan hari ini?</h2>
    <p>Bangun pemahaman, kenali kemampuanmu, dan temukan ritme belajar yang cocok untukmu.</p>
    <div class="actions">
      <button class="primary" on:click={() => (active ? resume(active.id) : go('tryout'))}
        >{active ? 'Lanjutkan Pengerjaan' : 'Pilih Tryout'}</button
      ><button class="secondary" on:click={() => go('practice')}>Latihan per Topik</button>
    </div>
  </div>
  <div class="hero-meta">
    <span class="small">Mulai dari yang sederhana</span><strong
      >Fokus. Latih.<br />Berkembang.</strong
    >
  </div>
</section>
<section class="stats">
  {#each stats as s}<div class="card stat">
      <div class="stat-top">{s[0]}<span class="iconbox"><Icon name={String(s[3])} /></span></div>
      <div class="stat-value">{s[1]}</div>
      <small>{s[2]}</small>
    </div>{/each}
</section>
<div class="columns">
  <section class="card">
    <div class="section-head">
      <h2>Perkembangan belajar</h2>
      <span class="badge">Akurasi jawaban</span>
    </div>
    {#if groups.length}{#each groups as g}<div class="chart">
          <h3>{g[0].name}</h3>
          <svg viewBox="0 0 560 180" role="img" aria-label={'Grafik akurasi ' + g[0].name}
            ><path d="M35 20H540 M35 85H540 M35 150H540" stroke="#e2e8f0" fill="none" /><text
              x="0"
              y="25"
              fill="#64748b"
              font-size="11">100</text
            ><text x="8" y="90" fill="#64748b" font-size="11">50</text><text
              x="15"
              y="155"
              fill="#64748b"
              font-size="11">0</text
            ><polyline
              points={g
                .map(
                  (a, i) =>
                    `${40 + (i * 490) / (g.length - 1)},${150 - (a.result?.accuracy || 0) * 1.3}`,
                )
                .join(' ')}
              fill="none"
              stroke="#0f766e"
              stroke-width="3"
            />{#each g as a, i}<circle
                cx={40 + (i * 490) / (g.length - 1)}
                cy={150 - (a.result?.accuracy || 0) * 1.3}
                r="4"
                fill="#0f766e"><title>{date(a.ended!)} · {a.result?.accuracy}%</title></circle
              >{/each}</svg
          >
          <div class="chart-dates">
            {#each g as a}<span>{date(a.ended!)} · {a.result?.accuracy}%</span>{/each}
          </div>
        </div>{/each}
      <p class="muted small">
        Grafik dipisah per paket atau topik. Perubahan isi paket dan soal acak dapat memengaruhi
        perbandingan.
      </p>{:else}<div class="chart-empty">
        <div class="empty">
          <div class="iconbox"><Icon name="chart" /></div>
          <h3>Perjalananmu dimulai di sini</h3>
          <p>Grafik muncul setelah 2 sesi selesai pada paket atau topik yang sama.</p>
        </div>
      </div>{/if}
  </section>
  <section class="card">
    <div class="section-head">
      <h2>Fokus Belajar</h2>
      <Icon name="target" />
    </div>
    {#each low.slice(0, 3) as t}<div class="step-row">
        <div class="grow">
          <h3>{t.topic}</h3>
          <span class="muted small"
            >{Math.round((t.correct / t.n) * 100)}% akurasi · {t.n} soal</span
          >
        </div>
        <button class="link" on:click={() => practice(t.topic, t.section)}>Latih Topik Ini</button>
      </div>{:else}<div class="empty">
        <div class="iconbox"><Icon name="target" /></div>
        <h3>Data belum cukup</h3>
        <p>Selesaikan latihan untuk mengetahui topik yang perlu mendapat perhatian.</p>
        <button class="link" on:click={() => go('practice')}>Mulai Latihan</button>
      </div>{/each}
    <div class="focus-note">
      Evaluasi ditampilkan setelah minimal 3 soal per topik. Lebih banyak latihan, lebih berarti
      datanya.
    </div>
  </section>
</div>
<div class="section-head">
  <h2>Siap untuk dikerjakan</h2>
  <button class="link" on:click={() => go('tryout')}>Lihat Semua</button>
</div>
<div class="packages">
  {#each data.packages.filter((p) => p.status === 'ready').slice(0, 2) as p}<PackageCard
      {p}
      attempt={data.attempts.find((a) => a.packageId === p.id)}
      open={() => open(p)}
    />{:else}<div class="card empty">Belum ada paket siap dikerjakan.</div>{/each}
</div>
