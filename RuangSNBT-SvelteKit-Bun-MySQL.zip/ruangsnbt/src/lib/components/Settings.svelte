<script lang="ts">
  import { onMount } from 'svelte';
  import type { User, Backup } from '#lib/types.ts';
  import { api, download } from '#lib/client.ts';
  import Modal from './Modal.svelte';
  export let user: User;
  export let updated: () => void;
  let name = user.name,
    message = '',
    error = '',
    busy = false,
    users: User[] = [],
    email = '',
    studentName = '',
    password = '',
    candidate: Backup | null = null,
    summary: { questions: number; packages: number } | null = null,
    resetUser: User | null = null,
    newPassword = '';
  async function run(action: () => Promise<void>) {
    busy = true;
    error = '';
    message = '';
    try {
      await action();
    } catch (e) {
      error = e instanceof Error ? e.message : 'Permintaan gagal.';
    } finally {
      busy = false;
    }
  }
  async function loadUsers() {
    users = await api<User[]>('users');
  }
  onMount(() => {
    if (user.role === 'owner') void run(loadUsers);
  });
  async function saveProfile() {
    await run(async () => {
      await api('profile', 'PATCH', { name });
      message = 'Profil berhasil disimpan.';
      updated();
    });
  }
  async function createStudent() {
    await run(async () => {
      await api('users', 'POST', { name: studentName, email, password });
      email = '';
      studentName = '';
      password = '';
      message = 'Akun peserta berhasil dibuat.';
      await loadUsers();
    });
  }
  async function exportBackup() {
    await run(async () => {
      download('ruangsnbt-konten.json', await api('backup'));
      message = 'Cadangan konten siap diunduh.';
    });
  }
  async function importFile(event: Event) {
    await run(async () => {
      const f = (event.currentTarget as HTMLInputElement).files?.[0];
      if (!f) return;
      if (f.size > 16 * 1024 * 1024) throw Error('Maksimal berkas 16 MB.');
      candidate = JSON.parse(await f.text());
      summary = await api('backup/validate', 'POST', candidate);
    });
  }
  async function commitImport() {
    await run(async () => {
      await api('backup/import', 'POST', candidate);
      candidate = null;
      summary = null;
      message = 'Cadangan konten berhasil digabungkan.';
      updated();
    });
  }
  async function resetPassword() {
    await run(async () => {
      await api('users/password', 'POST', { id: resetUser?.id, password: newPassword });
      resetUser = null;
      newPassword = '';
      message = 'Kata sandi diganti dan sesi lama peserta dicabut.';
    });
  }
</script>

<div class="page-title">
  <div>
    <h1>Pengaturan</h1>
    <span class="muted">Kelola profil dan jaga cadangan ruang belajarmu.</span>
  </div>
</div>
{#if error}<div class="notice warning" role="alert">
    {error}<button
      class="link"
      on:click={() => run(user.role === 'owner' ? loadUsers : async () => {})}>Coba Lagi</button
    >
  </div>{/if}{#if message}<div class="notice" role="status">{message}</div>{/if}
<div class="columns">
  <section class="card">
    <h2>Profil akun</h2>
    <form on:submit|preventDefault={saveProfile}>
      <div class="field">
        <label for="owner-name">Nama panggilan</label><input
          id="owner-name"
          bind:value={name}
          required
          maxlength="120"
        />
      </div>
      <button class="primary" disabled={busy}>Simpan Profil</button>
    </form>
    <div class="notice">
      <strong>Data tersimpan di server</strong><br />Soal, paket, jawaban, dan hasil tersimpan di
      MySQL. Masuk menggunakan akun yang sama untuk mengakses data dari perangkat lain. Perubahan
      yang belum tersinkron saat offline masih berada di perangkat asal.
    </div>
    <p class="muted small">
      Satu sesi aktif per akun. Hindari mengerjakan sesi yang sama dari beberapa tab atau perangkat
      sekaligus.
    </p>
  </section>
  {#if user.role === 'owner'}<section class="card">
      <h2>Cadangan konten</h2>
      <p class="muted">
        Ekspor bank soal, versi soal, dan paket. Akun, kata sandi, dan riwayat peserta dicadangkan
        melalui backup MySQL oleh administrator server.
      </p>
      <button class="primary" on:click={exportBackup} disabled={busy}>Ekspor Cadangan JSON</button>
      <div class="field" style="margin-top:24px">
        <label for="import-file">Impor cadangan konten</label><input
          id="import-file"
          type="file"
          accept="application/json,.json"
          on:change={importFile}
          disabled={busy}
        /><small
          >Impor digabung berdasarkan ID. Soal yang sama memperoleh versi baru; percobaan lama tetap
          utuh. Gunakan skrip konversi untuk JSON aplikasi versi browser.</small
        >
      </div>
    </section>{/if}
</div>
{#if user.role === 'owner'}<section class="card">
    <h2>Akun peserta</h2>
    <p class="muted">Buat akun secara pribadi. Tidak ada pendaftaran publik.</p>
    <form on:submit|preventDefault={createStudent}>
      <div class="form-grid">
        <div class="field">
          <label for="student-name">Nama peserta</label><input
            id="student-name"
            bind:value={studentName}
            required
            maxlength="120"
          />
        </div>
        <div class="field">
          <label for="student-email">Email peserta</label><input
            id="student-email"
            type="email"
            bind:value={email}
            required
          />
        </div>
        <div class="field">
          <label for="student-password">Kata sandi awal</label><input
            id="student-password"
            type="password"
            bind:value={password}
            minlength="12"
            maxlength="128"
            required
            autocomplete="new-password"
          /><small>Minimal 12 karakter. Bagikan langsung kepada peserta.</small>
        </div>
      </div>
      <button class="primary" disabled={busy}>Buat Akun Peserta</button>
    </form>
    <div class="table-wrap" style="margin-top:24px">
      <table class="desktop-table">
        <thead><tr><th>Nama</th><th>Email</th><th>Peran</th><th>Aksi</th></tr></thead><tbody
          >{#each users as u}<tr
              ><td>{u.name}</td><td>{u.email}</td><td
                >{u.role === 'owner' ? 'Pemilik' : 'Peserta'}</td
              ><td
                >{#if u.role === 'student'}<button class="link" on:click={() => (resetUser = u)}
                    >Ganti Kata Sandi</button
                  >{/if}</td
              ></tr
            >{/each}</tbody
        >
      </table>
    </div>
  </section>{/if}
{#if summary}<Modal title="Impor cadangan konten?" close={() => (summary = null)}
    ><p>Cadangan valid: {summary.questions} soal dan {summary.packages} paket.</p>
    <div class="notice warning">
      Konten dengan ID sama akan diperbarui. Ekspor cadangan sebelum melanjutkan. Akun dan riwayat
      peserta tidak dihapus.
    </div>
    {#if error}<p class="error-text">{error}</p>{/if}
    <div class="actions">
      <button on:click={() => (summary = null)} disabled={busy}>Batal</button><button
        class="primary"
        on:click={commitImport}
        disabled={busy}>Impor Konten</button
      >
    </div></Modal
  >{/if}
{#if resetUser}<Modal title="Ganti kata sandi peserta" close={() => (resetUser = null)}
    ><p>{resetUser.name} · {resetUser.email}</p>
    <form on:submit|preventDefault={resetPassword}>
      <div class="field">
        <label for="reset-password">Kata sandi baru</label><input
          id="reset-password"
          type="password"
          bind:value={newPassword}
          minlength="12"
          maxlength="128"
          required
          autocomplete="new-password"
        />
      </div>
      {#if error}<p class="error-text">{error}</p>{/if}<button class="primary" disabled={busy}
        >Simpan Kata Sandi</button
      >
    </form></Modal
  >{/if}
