<script lang="ts">
  export let text = '';
  export let image = '';
  export let alt = '';
  export let table = '';
</script>

<div class="question-text">{text}</div>
{#if image}<img class="question-image" src={image} {alt} />{/if}{#if table.trim()}<div
    class="table-wrap"
  >
    <table>
      <tbody
        >{#each table.trim().split('\n') as row, i}<tr
            >{#each row.split('|') as cell}{#if i === 0}<th>{cell.trim()}</th>{:else}<td
                  >{cell.trim()}</td
                >{/if}{/each}</tr
          >{/each}</tbody
      >
    </table>
  </div>{/if}
