<script lang="ts">
  import type { Topic } from '#lib/types.ts';
  import Modal from './Modal.svelte';
  export let topic: Topic;
  export let close: () => void;
  export let start: (data: Record<string, unknown>) => Promise<void>;
  let difficulty = 'all',
    count = 1,
    timed = false,
    minutes = 10,
    busy = false,
    message = '';
  $: available = difficulty === 'all' ? topic.available : topic.difficulties[difficulty] || 0;
  $: count = Math.max(1, Math.min(count, available));
  async function begin() {
    busy = true;
    try {
      await start({
        topic: topic.topic,
        section: topic.section,
        count,
        difficulty,
        minutes: timed ? minutes : 0,
      });
    } catch (e) {
      message = e instanceof Error ? e.message : 'Latihan gagal dimulai.';
    } finally {
      busy = false;
    }
  }
</script>

<Modal title="Atur latihan topik" {close}
  ><h3>{topic.topic}</h3>
  <p class="muted">{topic.section}</p>
  <div class="field">
    <label for="pdiff">Kesulitan editorial</label><select id="pdiff" bind:value={difficulty}
      ><option value="all">Semua tingkat</option><option>Mudah</option><option>Sedang</option
      ><option>Sulit</option></select
    >
  </div>
  <div class="field">
    <label for="pcount">Jumlah soal</label><select id="pcount" bind:value={count}
      >{#each Array.from({ length: Math.min(200, available) }, (_, i) => i + 1) as n}<option
          value={n}>{n} soal</option
        >{/each}</select
    ><small>Tersedia {available} soal pada pilihan ini.</small>
  </div>
  <label class="check"><input type="checkbox" bind:checked={timed} />Gunakan timer</label
  >{#if timed}<div class="field">
      <label for="pminutes">Durasi (menit)</label><input
        id="pminutes"
        type="number"
        bind:value={minutes}
        min="1"
        max="240"
      />
    </div>{/if}
  <div class="notice">
    Pembahasan dibuka setelah jawaban diperiksa. Jawaban pertama yang dikonfirmasi menjadi dasar
    hasil.
  </div>
  {#if message}<p class="error-text">{message}</p>{/if}<button
    class="primary"
    disabled={busy || !available}
    on:click={begin}>{busy ? 'Menyiapkan…' : 'Mulai Latihan'}</button
  ></Modal
>
