<script lang="ts">
  export let name = 'file';
  const paths: Record<string, string> = {
    grid: 'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z',
    book: 'M12 5C8 2 3 4 3 4v15s5-2 9 1c4-3 9-1 9-1V4s-5-2-9 1z M12 5v15',
    file: 'M6 3h9l4 4v14H6z M14 3v5h5 M9 12h7 M9 16h5',
    target: 'M21 12a9 9 0 1 1-9-9 M16 12a4 4 0 1 1-4-4 M12 12l9-9 M16 3h5v5',
    clock: 'M12 8v5l3 2 M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0',
    layers: 'M3 7l9-4 9 4-9 4z M3 12l9 4 9-4 M3 17l9 4 9-4',
    settings:
      'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M12 2v3 M12 19v3 M2 12h3 M19 12h3 M5 5l2 2 M17 17l2 2 M5 19l2-2 M17 7l2-2',
    chart: 'M4 3v17h17 M8 15l4-5 4 2 5-7',
    check: 'M5 12l4 4L19 6',
    plus: 'M12 5v14 M5 12h14',
    menu: 'M4 6h16 M4 12h16 M4 18h16',
    flag: 'M5 21V3 M5 3c5-3 9 3 14 0v10c-5 3-9-3-14 0',
  };
</script>

<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d={paths[name] || paths.file} /></svg
>
