<script lang="ts">
  import type { ExamPackage, Question } from '#lib/types.ts';
  import { SECTIONS } from '#lib/types.ts';
  import { api, ApiError } from '#lib/client.ts';
  import Modal from './Modal.svelte';
  export let initial: ExamPackage | null = null;
  export let questions: Question[];
  export let close: () => void;
  export let saved: () => void;
  const newSection = () => ({
    id: crypto.randomUUID(),
    name: SECTIONS[0] as string,
    duration: 10,
    questionIds: [] as string[],
  });
  let p: ExamPackage = initial
    ? structuredClone(initial)
    : {
        id: crypto.randomUUID(),
        name: '',
        description: '',
        mode: 'simulasi',
        status: 'draft',
        demo: false,
        allowBack: false,
        shuffleOptions: false,
        shuffleQuestions: false,
        sections: [newSection()],
      };
  let busy = false,
    message = '',
    errors: Record<string, string> = {};
  function move(i: number, d: number) {
    [p.sections[i], p.sections[i + d]] = [p.sections[i + d], p.sections[i]];
    p = { ...p };
  }
  async function save() {
    busy = true;
    message = '';
    errors = {};
    try {
      await api('packages', 'POST', p);
      saved();
    } catch (e) {
      message = e instanceof Error ? e.message : 'Gagal menyimpan.';
      if (e instanceof ApiError) errors = e.fields;
    } finally {
      busy = false;
    }
  }
</script>

<Modal title="Susun paket ujian" {close} wide
  ><form on:submit|preventDefault={save}>
    <div class="form-grid">
      <div class="field">
        <label for="pname">Nama paket</label><input
          id="pname"
          bind:value={p.name}
          required
          maxlength="200"
        /><span class="error-text">{errors.name || ''}</span>
      </div>
      <div class="field">
        <label for="pmode">Mode</label><select id="pmode" bind:value={p.mode}
          ><option value="simulasi">Simulasi</option><option value="latihan">Latihan</option
          ></select
        >
      </div>
      <div class="field full">
        <label for="pdesc">Deskripsi</label><textarea id="pdesc" bind:value={p.description}
        ></textarea>
      </div>
    </div>
    <h3>Urutan bagian</h3>
    {#each p.sections as s, i (s.id)}<div class="section-edit">
        <div class="section-head">
          <h3>Bagian {i + 1}</h3>
          <div class="actions">
            {#if i > 0}<button type="button" class="link" on:click={() => move(i, -1)}>Naik</button
              >{/if}{#if i < p.sections.length - 1}<button
                type="button"
                class="link"
                on:click={() => move(i, 1)}>Turun</button
              >{/if}{#if p.sections.length > 1}<button
                type="button"
                class="link danger"
                on:click={() => (p.sections = p.sections.filter((_, j) => j !== i))}>Hapus</button
              >{/if}
          </div>
        </div>
        <div class="form-grid">
          <div class="field">
            <label for={'ps' + i}>Bagian tes</label><select
              id={'ps' + i}
              bind:value={s.name}
              on:change={() => (s.questionIds = [])}
              >{#each SECTIONS as name}<option>{name}</option>{/each}</select
            >
          </div>
          <div class="field">
            <label for={'pd' + i}>Durasi (menit)</label><input
              id={'pd' + i}
              type="number"
              min="1"
              max="240"
              step="1"
              bind:value={s.duration}
              required
            />
          </div>
        </div>
        <div class="question-pick">
          {#each questions.filter((q) => q.section === s.name && q.status === 'ready' && !q.archived) as q}<label
              class="check"
              ><input type="checkbox" value={q.id} bind:group={s.questionIds} /><span
                >{q.text.slice(0, 130)}<br /><span class="small muted"
                  >{q.topic} · {q.difficulty}{q.demo ? ' · Demo' : ''}</span
                ></span
              ></label
            >{:else}<div class="empty-inline">
              Belum ada soal siap digunakan di bagian ini.
            </div>{/each}
        </div>
        <div class="error-text">{errors['section' + i] || ''}</div>
      </div>{/each}<button
      type="button"
      on:click={() => (p.sections = [...p.sections, newSection()])}>Tambah Bagian</button
    >
    <div class="form-grid" style="margin-top:24px">
      <div>
        <label class="check"
          ><input type="checkbox" bind:checked={p.shuffleQuestions} />Acak urutan soal</label
        ><label class="check"
          ><input type="checkbox" bind:checked={p.shuffleOptions} />Acak pilihan jawaban</label
        ><label class="check"
          ><input type="checkbox" bind:checked={p.allowBack} />Izinkan kembali ke bagian sebelumnya</label
        ><small class="muted"
          >Perubahan jawaban tetap mengikuti batas waktu bagian masing-masing.</small
        >
      </div>
      <div class="field">
        <label for="pstatus">Status</label><select id="pstatus" bind:value={p.status}
          ><option value="draft">Draft</option><option value="ready">Siap Dikerjakan</option
          ></select
        >
      </div>
    </div>
    <div class="notice">
      Total {p.sections.reduce((n, s) => n + s.questionIds.length, 0)} soal · {p.sections.reduce(
        (n, s) => n + (s.duration || 0),
        0,
      )} menit. Pengaturan ini bukan ketentuan resmi SNBT.
    </div>
    {#if message}<div class="notice warning" role="alert">{message}</div>{/if}<button
      class="primary"
      disabled={busy}>{busy ? 'Menyimpan…' : 'Simpan Paket'}</button
    >
  </form></Modal
>
