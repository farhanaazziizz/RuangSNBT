<script lang="ts">
  import type { ExamPackage, AttemptSummary } from '#lib/types.ts';
  import Icon from './Icon.svelte';
  export let p: ExamPackage;
  export let attempt: AttemptSummary | undefined = undefined;
  export let open: () => void;
</script>

<article class="card package">
  <div class="section-head" style="margin:0">
    <span class="iconbox"><Icon name="file" /></span>
    <div class="chips">
      {#if p.demo}<span class="badge demo">Paket Demo</span>{/if}<span
        class="badge"
        class:amber={attempt?.status === 'active'}
        >{attempt?.status === 'active'
          ? 'Sedang Dikerjakan'
          : attempt
            ? 'Selesai'
            : 'Belum Dimulai'}</span
      >
    </div>
  </div>
  <h3>{p.name}</h3>
  <p class="muted">{p.description}</p>
  <div class="chips">
    {#each p.sections as s}<span class="chip">{s.name}</span>{/each}
  </div>
  <div class="package-footer">
    <div class="meta">
      <span
        ><Icon name="file" />{p.sections.reduce((n, s) => n + s.questionIds.length, 0)} soal</span
      ><span><Icon name="clock" />{p.sections.reduce((n, s) => n + s.duration, 0)} menit</span>
    </div>
    <button class="primary" on:click={open}
      >{attempt?.status === 'active'
        ? 'Lanjutkan'
        : attempt
          ? 'Lihat Hasil'
          : 'Lihat Detail'}</button
    >
  </div>
</article>
