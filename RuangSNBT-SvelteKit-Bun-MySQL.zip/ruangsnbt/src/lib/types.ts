export const SECTIONS = [
  'Penalaran Umum',
  'Pengetahuan dan Pemahaman Umum',
  'Pemahaman Bacaan dan Menulis',
  'Pengetahuan Kuantitatif',
  'Literasi Bahasa Indonesia',
  'Literasi Bahasa Inggris',
  'Penalaran Matematika',
] as const;
export type User = { id: string; name: string; email: string; role: 'owner' | 'student' };
export type Question = {
  id: string;
  version: number;
  section: string;
  topic: string;
  type: 'single';
  text: string;
  options: string[];
  key: number;
  explanation: string;
  difficulty: 'Mudah' | 'Sedang' | 'Sulit';
  status: 'draft' | 'ready';
  demo: boolean;
  archived: boolean;
  image: string;
  alt: string;
  table: string;
  source: string;
};
export type PackageSection = { id: string; name: string; duration: number; questionIds: string[] };
export type ExamPackage = {
  id: string;
  name: string;
  description: string;
  mode: 'simulasi' | 'latihan';
  status: 'draft' | 'ready';
  demo: boolean;
  allowBack: boolean;
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
  sections: PackageSection[];
};
export type SnapshotQuestion = Question & { instanceId: string };
export type AttemptSection = {
  id: string;
  name: string;
  duration: number;
  questions: SnapshotQuestion[];
  started: number | null;
  deadline: number | null;
  ended: number | null;
  elapsed: number;
};
export type Answer = {
  option: number | null;
  flagged: boolean;
  confirmed: boolean;
  revision: number;
};
export type Metrics = {
  total: number;
  correct: number;
  wrong: number;
  empty: number;
  accuracy: number;
};
export type Attempt = {
  id: string;
  userId: string;
  packageId: string | null;
  name: string;
  mode: 'simulasi' | 'latihan';
  demo: boolean;
  allowBack: boolean;
  practiceTopic?: string;
  started: number;
  ended: number | null;
  elapsed: number;
  status: 'active' | 'done';
  sectionIndex: number;
  sections: AttemptSection[];
  answers: Record<string, Answer>;
  result?: Metrics;
};
export type PublicQuestion = Omit<SnapshotQuestion, 'key' | 'explanation' | 'source'> & {
  key?: number;
  explanation?: string;
};
export type PublicAttempt = Omit<Attempt, 'sections'> & {
  sections: (Omit<AttemptSection, 'questions'> & { questions: PublicQuestion[] })[];
  serverNow: number;
};
export type AttemptSummary = Omit<Attempt, 'sections' | 'answers'> & {
  total: number;
  topics: { topic: string; section: string; n: number; correct: number }[];
};
export type Topic = {
  topic: string;
  section: string;
  available: number;
  difficulties: Record<string, number>;
};
export type Bootstrap = {
  user: User;
  questions: Question[];
  packages: ExamPackage[];
  attempts: AttemptSummary[];
  topics: Topic[];
};
export type Backup = {
  format: 'ruangsnbt-content';
  version: 2;
  questions: Question[];
  packages: ExamPackage[];
  questionVersions: Question[];
};
