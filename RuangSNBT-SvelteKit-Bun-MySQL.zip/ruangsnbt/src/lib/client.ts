export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public fields: Record<string, string> = {},
  ) {
    super(message);
  }
}
export async function api<T>(path: string, method = 'GET', data?: unknown): Promise<T> {
  const r = await fetch('/api/' + path, {
    method,
    headers: data === undefined ? {} : { 'Content-Type': 'application/json' },
    body: data === undefined ? undefined : JSON.stringify(data),
  });
  let d: any;
  try {
    d = await r.json();
  } catch {
    throw new ApiError('Layanan tidak dapat dihubungi. Coba lagi.', r.status);
  }
  if (!r.ok) throw new ApiError(d.message || 'Permintaan gagal.', r.status, d.fields || {});
  return d as T;
}
export const date = (n: number) =>
  new Date(n).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
export const duration = (n: number) => `${Math.floor(n / 60000)} m ${Math.floor(n / 1000) % 60} d`;
export const timer = (n: number) =>
  `${String(Math.floor(Math.max(0, n) / 60000)).padStart(2, '0')}:${String(Math.floor(Math.max(0, n) / 1000) % 60).padStart(2, '0')}`;
export function download(name: string, data: unknown) {
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }),
  );
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
