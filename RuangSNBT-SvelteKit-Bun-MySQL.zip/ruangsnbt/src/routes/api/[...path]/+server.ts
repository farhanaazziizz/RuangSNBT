import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { AppError, validateBackup } from '#lib/server/validation.ts';
import { db } from '#lib/server/db.ts';
import { login, secureCookie, createUser } from '#lib/server/auth.ts';
import {
  bootstrap,
  saveQuestion,
  savePackage,
  start,
  attemptOperation,
  exportContent,
  importContent,
} from '#lib/server/repository.ts';
import { saveAnswer, finishSection } from '#lib/server/domain.ts';
const handler: RequestHandler = async (e) => {
  try {
    const path = e.params.path || '',
      method = e.request.method;
    if (path === 'health' && method === 'GET') {
      await db()`SELECT 1`;
      return json({ status: 'ok' });
    }
    let body: any = {};
    if (!['GET', 'HEAD'].includes(method)) {
      const raw = await e.request.text();
      if (new TextEncoder().encode(raw).length > 16 * 1024 * 1024)
        throw new AppError(413, 'Data maksimal 16 MB.');
      try {
        body = JSON.parse(raw || '{}');
      } catch {
        throw new AppError(400, 'JSON tidak valid.');
      }
    }
    if (path === 'auth/login' && method === 'POST') {
      const { token, user } = await login(body.email, body.password);
      e.cookies.set('session', token, {
        path: '/',
        httpOnly: true,
        secure: secureCookie(),
        sameSite: 'lax',
        maxAge: 7 * 86400,
      });
      return json({ user });
    }
    const user = e.locals.user;
    if (!user) throw new AppError(401, 'Silakan masuk kembali.');
    if (path === 'auth/logout' && method === 'POST') {
      await db()`DELETE FROM sessions WHERE token_hash=${e.locals.sessionHash!}`;
      e.cookies.delete('session', { path: '/' });
      return json({ ok: true });
    }
    if (path === 'bootstrap' && method === 'GET') return json(await bootstrap(user));
    if (path === 'profile' && method === 'PATCH') {
      if (typeof body.name !== 'string' || !body.name.trim() || body.name.length > 120)
        throw new AppError(400, 'Nama wajib diisi (maks. 120 karakter).');
      await db()`UPDATE users SET name=${body.name.trim()} WHERE id=${user.id}`;
      return json({ ok: true });
    }
    if (path === 'attempts' && method === 'POST') return json(await start(user, body));
    const match = path.match(/^attempts\/([a-zA-Z0-9_-]+)(?:\/(answers|submit))?$/);
    if (match) {
      const [, id, op] = match;
      if (!op && method === 'GET') return json(await attemptOperation(user, id));
      if (op === 'answers' && method === 'PUT')
        return json(await attemptOperation(user, id, (a, now) => saveAnswer(a, body, now)));
      if (op === 'submit' && method === 'POST')
        return json(
          await attemptOperation(user, id, (a, now) => {
            if (!Number.isInteger(body.sectionIndex))
              throw new AppError(400, 'Bagian tidak valid.');
            if (a.status === 'done' || body.sectionIndex < a.sectionIndex) return;
            if (body.sectionIndex !== a.sectionIndex)
              throw new AppError(409, 'Bagian sudah berubah. Muat ulang sesi.');
            finishSection(a, now);
          }),
        );
    }
    if (user.role !== 'owner')
      throw new AppError(403, 'Hanya pemilik yang dapat mengelola konten.');
    if (path === 'questions' && method === 'POST') return json(await saveQuestion(body));
    if (path === 'packages' && method === 'POST') return json(await savePackage(body));
    if (path === 'users' && method === 'GET')
      return json(await db()`SELECT id,name,email,role FROM users ORDER BY created_at DESC`);
    if (path === 'users' && method === 'POST')
      return json(await createUser({ ...body, role: 'student' }));
    if (path === 'users/password' && method === 'POST') {
      if (
        typeof body.id !== 'string' ||
        typeof body.password !== 'string' ||
        body.password.length < 12 ||
        body.password.length > 128
      )
        throw new AppError(400, 'Kata sandi harus 12–128 karakter.');
      const [u] = await db()`SELECT id FROM users WHERE id=${body.id} AND role='student'`;
      if (!u) throw new AppError(404, 'Peserta tidak ditemukan.');
      const password = await Bun.password.hash(body.password, { algorithm: 'argon2id' });
      await db().begin(async (tx) => {
        await tx`UPDATE users SET password_hash=${password} WHERE id=${u.id}`;
        await tx`DELETE FROM sessions WHERE user_id=${u.id}`;
      });
      return json({ ok: true });
    }
    if (path === 'backup' && method === 'GET')
      return json(await exportContent(), {
        headers: { 'Content-Disposition': 'attachment; filename="ruangsnbt-konten.json"' },
      });
    if (path === 'backup/validate' && method === 'POST') {
      const b = validateBackup(body);
      return json({ questions: b.questions.length, packages: b.packages.length });
    }
    if (path === 'backup/import' && method === 'POST')
      return json(await importContent(validateBackup(body)));
    throw new AppError(404, 'Halaman API tidak ditemukan.');
  } catch (error) {
    if (error instanceof AppError)
      return json({ message: error.message, fields: error.fields }, { status: error.status });
    console.error('API failed', error);
    return json(
      { message: 'Layanan data sedang bermasalah. Perubahan belum dikonfirmasi; coba lagi.' },
      { status: 503 },
    );
  }
};
export const GET = handler,
  POST = handler,
  PUT = handler,
  PATCH = handler;
