<script lang="ts">
  import '../app.css';
</script>

<svelte:head
  ><title>RuangSNBT — Ruang belajarmu</title><meta
    name="description"
    content="Latihan SNBT, bank soal, simulasi dan evaluasi belajar."
  /></svelte:head
>
<slot />
