<script lang="ts">
  import { onMount } from 'svelte';
  import type { Bootstrap, Question, ExamPackage, PublicAttempt, Topic, User } from '#lib/types.ts';
  import { SECTIONS } from '#lib/types.ts';
  import { api, date, duration } from '#lib/client.ts';
  import Icon from '#lib/components/Icon.svelte';
  import Dashboard from '#lib/components/Dashboard.svelte';
  import PackageCard from '#lib/components/PackageCard.svelte';
  import QuestionEditor from '#lib/components/QuestionEditor.svelte';
  import PackageEditor from '#lib/components/PackageEditor.svelte';
  import PracticeDialog from '#lib/components/PracticeDialog.svelte';
  import Exam from '#lib/components/Exam.svelte';
  import Results from '#lib/components/Results.svelte';
  import Settings from '#lib/components/Settings.svelte';
  export let data: { user: User };
  let store: Bootstrap | null = null,
    view = 'dashboard',
    loading = true,
    working = false,
    error = '',
    success = '',
    menu = false,
    search = '',
    status = 'all',
    questionEdit: Question | null = null,
    questionModal = false,
    packageEdit: ExamPackage | null = null,
    packageModal = false,
    detail: ExamPackage | null = null,
    attempt: PublicAttempt | null = null,
    topic: Topic | null = null;
  const nav = [
    ['dashboard', 'Dashboard', 'grid'],
    ['tryout', 'Tryout Saya', 'file'],
    ['practice', 'Latihan Topik', 'target'],
    ['history', 'Riwayat Hasil', 'clock'],
    ['bank', 'Bank Soal', 'book'],
    ['packages', 'Paket Ujian', 'layers'],
  ];
  function go(v: string) {
    view = v;
    search = '';
    status = 'all';
    menu = false;
    error = '';
    if (typeof window !== 'undefined') window.scrollTo(0, 0);
  }
  async function load() {
    loading = true;
    error = '';
    try {
      store = await api<Bootstrap>('bootstrap');
    } catch (e) {
      error = e instanceof Error ? e.message : 'Data belum dapat dimuat.';
    } finally {
      loading = false;
    }
  }
  async function action(fn: () => Promise<void>) {
    if (working) return;
    working = true;
    error = '';
    try {
      await fn();
    } catch (e) {
      error = e instanceof Error ? e.message : 'Permintaan gagal.';
    } finally {
      working = false;
    }
  }
  async function openAttempt(id: string) {
    await action(async () => {
      attempt = await api<PublicAttempt>('attempts/' + id);
      go(attempt.status === 'done' ? 'result' : 'exam');
    });
  }
  function openPackage(p: ExamPackage) {
    const previous = store?.attempts.find((a) => a.packageId === p.id);
    if (previous) void openAttempt(previous.id);
    else {
      detail = p;
      go('detail');
    }
  }
  async function start(params: Record<string, unknown>) {
    const a = await api<PublicAttempt>('attempts', 'POST', params);
    attempt = a;
    topic = null;
    go(a.status === 'active' ? 'exam' : 'result');
  }
  function practice(name: string, section: string) {
    const found = store?.topics.find((t) => t.topic === name && t.section === section);
    if (found) topic = found;
    else error = 'Topik ini belum memiliki soal siap digunakan.';
  }
  async function saved(kind: string) {
    questionModal = false;
    packageModal = false;
    await load();
    success = kind + ' berhasil disimpan.';
    setTimeout(() => (success = ''), 4000);
  }
  async function archive(q: Question) {
    await action(async () => {
      await api('questions', 'POST', { ...q, archived: !q.archived });
      await saved(q.archived ? 'Pemulihan soal' : 'Pengarsipan soal');
    });
  }
  function duplicate(q: Question) {
    questionEdit = {
      ...structuredClone(q),
      id: crypto.randomUUID(),
      version: 1,
      status: 'draft',
      demo: false,
      text: q.text + ' (Salinan)',
    };
    questionModal = true;
  }
  async function completed(a: PublicAttempt) {
    attempt = a;
    go('result');
    await load();
  }
  async function logout() {
    await action(async () => {
      await api('auth/logout', 'POST', {});
      location.href = '/login';
    });
  }
  $: owner = store?.user.role === 'owner';
  $: visibleNav = nav.filter((_, i) => i < 4 || owner);
  $: filteredQuestions =
    store?.questions.filter(
      (q) =>
        (status === 'archived' ? q.archived : !q.archived) &&
        (status === 'all' || status === 'archived' || q.status === status) &&
        (q.text + ' ' + q.topic).toLowerCase().includes(search.toLowerCase()),
    ) || [];
  $: filteredPackages =
    store?.packages.filter(
      (p) =>
        p.status === 'ready' &&
        p.name.toLowerCase().includes(search.toLowerCase()) &&
        (status === 'all' ||
          (store?.attempts.find((a) => a.packageId === p.id)?.status || 'new') === status),
    ) || [];
  onMount(load);
</script>

{#if view === 'exam' && attempt}<Exam
    {attempt}
    exit={() => {
      go('dashboard');
      void load();
    }}
    {completed}
  />{:else}<aside class="sidebar" class:open={menu}>
    <div class="brand"><img src="/icon.svg" alt="" /><span>Ruang<span>SNBT</span></span></div>
    <div class="navlabel">AREA BELAJAR</div>
    {#each visibleNav as n, i}{#if i === 4}<div class="navlabel">KELOLA</div>{/if}<button
        class="navitem"
        class:active={view === n[0]}
        on:click={() => go(n[0])}><Icon name={n[2]} />{n[1]}</button
      >{/each}
    <div class="sidebar-bottom">
      <button class="navitem" class:active={view === 'settings'} on:click={() => go('settings')}
        ><Icon name="settings" />Pengaturan</button
      ><button class="navitem" disabled={working} on:click={logout}>Keluar Akun</button>
      <div class="storage-mini">
        Data tersimpan di server<br />{owner ? 'Akun pemilik' : 'Akun peserta'}
      </div>
    </div>
  </aside>
  <div class="main">
    <header class="topbar">
      <div class="breadcrumb">
        <button class="mobile-menu" aria-label="Buka navigasi" on:click={() => (menu = !menu)}
          ><Icon name="menu" /></button
        ><span>Area {['bank', 'packages'].includes(view) ? 'Kelola' : 'Belajar'}</span><span>/</span
        ><strong
          >{nav.find((n) => n[0] === view)?.[1] ||
            (
              { settings: 'Pengaturan', result: 'Hasil Latihan', detail: 'Detail Paket' } as Record<
                string,
                string
              >
            )[view]}</strong
        >
      </div>
      <button class="account link" on:click={() => go('settings')}
        ><span class="avatar">{(store?.user.name || data.user.name).slice(0, 1).toUpperCase()}</span
        ><span class="account-text">{store?.user.name || data.user.name}</span></button
      >
    </header>
    <main class="content">
      {#if error}<div class="notice warning" role="alert">
          {error}<button class="link" on:click={load}>Coba Lagi</button>
        </div>{/if}{#if success}<div class="notice" role="status">
          {success}
        </div>{/if}{#if working}<div class="notice" role="status">
          Memproses…
        </div>{/if}{#if loading}<div class="card loading" role="status">
          Memuat ruang belajarmu…
        </div>{:else if store}
        {#if view === 'dashboard'}<Dashboard
            data={store}
            {go}
            open={openPackage}
            resume={openAttempt}
            {practice}
          />
        {:else if view === 'tryout'}<div class="page-title">
            <div>
              <h1>Tryout Saya</h1>
              <span class="muted">Luangkan waktu, ukur pemahaman, dan pelajari hasilnya.</span>
            </div>
          </div>
          <div class="toolbar">
            <input
              aria-label="Cari paket"
              placeholder="Cari nama paket…"
              bind:value={search}
            /><select aria-label="Filter status" bind:value={status}
              ><option value="all">Semua status</option><option value="new">Belum Dimulai</option
              ><option value="active">Sedang Dikerjakan</option><option value="done">Selesai</option
              ></select
            >
          </div>
          <div class="packages">
            {#each filteredPackages as p}<PackageCard
                {p}
                attempt={store.attempts.find((a) => a.packageId === p.id)}
                open={() => openPackage(p)}
              />{:else}<div class="card empty">
                <h3>Paket tidak ditemukan</h3>
                <p>Coba pencarian lain atau tunggu paket diaktifkan oleh pemilik.</p>
              </div>{/each}
          </div>
          <div class="notice">
            Susunan, durasi, dan hasil paket merupakan pengaturan latihan internal, bukan ketentuan
            resmi SNBT.
          </div>
        {:else if view === 'detail' && detail}<div class="page-title">
            <div>
              <h1>{detail.name}</h1>
              <span class="muted"
                >{detail.demo ? 'Paket Demo · Soal buatan sendiri' : 'Paket latihan'}</span
              >
            </div>
          </div>
          <div class="columns">
            <div class="card">
              <h2>Tentang paket ini</h2>
              <p class="muted">{detail.description}</p>
              <h3>Urutan bagian</h3>
              {#each detail.sections as s, i}<div class="step-row">
                  <span class="step-number">{i + 1}</span>
                  <div class="grow">
                    <h3>{s.name}</h3>
                    <span class="muted">{s.questionIds.length} soal</span>
                  </div>
                  <strong>{s.duration} menit</strong>
                </div>{/each}
            </div>
            <div class="card">
              <h2>Sebelum mulai</h2>
              <p>Mode: <strong>{detail.mode === 'simulasi' ? 'Simulasi' : 'Latihan'}</strong></p>
              <p>
                {detail.allowBack
                  ? 'Anda dapat kembali ke bagian sebelumnya selama batas waktu bagian itu belum habis.'
                  : 'Setelah berpindah bagian, Anda tidak dapat kembali ke bagian sebelumnya.'}
              </p>
              <p>
                {detail.mode === 'simulasi'
                  ? 'Pembahasan tersedia setelah seluruh sesi selesai.'
                  : 'Pembahasan tersedia setelah jawaban diperiksa.'}
              </p>
              <div class="notice">
                Timer dimulai setelah menekan “Mulai Tryout”. Waktu tetap berjalan ketika koneksi
                terputus atau tab ditutup. Jawaban yang tiba setelah batas waktu server akan
                ditolak.
              </div>
              <div class="actions">
                <button
                  class="primary"
                  disabled={working || detail.status !== 'ready'}
                  on:click={() => action(() => start({ packageId: detail!.id }))}
                  >Mulai Tryout</button
                ><button class="link" on:click={() => go('tryout')}>Kembali</button>
              </div>
            </div>
          </div>
        {:else if view === 'practice'}<div class="page-title">
            <div>
              <h1>Latihan Topik</h1>
              <span class="muted">Fokus pada satu topik. Pahami, bukan sekadar menjawab.</span>
            </div>
          </div>
          {#each SECTIONS as section}{#if store.topics.some((t) => t.section === section)}<section
                style="margin-bottom:28px"
              >
                <h2>{section}</h2>
                <div class="topics">
                  {#each store.topics.filter((t) => t.section === section) as t}<button
                      class="card topic-card"
                      style="display:block;text-align:left"
                      on:click={() => (topic = t)}
                      ><div class="section-head">
                        <span class="iconbox"><Icon name="target" /></span><span class="badge"
                          >{t.available} soal</span
                        >
                      </div>
                      <h3>{t.topic}</h3>
                      <span class="muted small">Pilih jumlah soal dan kesulitan editorial.</span
                      ></button
                    >{/each}
                </div>
              </section>{/if}{/each}{#if !store.topics.length}<div class="card empty">
              Belum ada soal siap digunakan. Topik tersedia setelah pemilik menambahkan soal.
            </div>{/if}
        {:else if view === 'history'}<div class="page-title">
            <div>
              <h1>Riwayat Hasil</h1>
              <span class="muted">Setiap percobaan adalah bagian dari proses belajarmu.</span>
            </div>
          </div>
          <div class="card table-wrap">
            {#if store.attempts.some((a) => a.status === 'done')}<table class="desktop-table">
                <thead
                  ><tr
                    ><th>Paket / topik</th><th>Tanggal</th><th>Mode</th><th>Akurasi</th><th
                      >Waktu</th
                    ><th></th></tr
                  ></thead
                ><tbody
                  >{#each store.attempts.filter((a) => a.status === 'done') as a}<tr
                      ><td
                        ><strong>{a.name}</strong>{#if a.demo}<span class="badge demo">Demo</span
                          >{/if}</td
                      ><td data-label="Tanggal">{date(a.ended!)}</td><td data-label="Mode"
                        >{a.mode === 'simulasi' ? 'Simulasi' : 'Latihan'}</td
                      ><td data-label="Akurasi">{a.result?.accuracy}%</td><td data-label="Waktu"
                        >{duration(a.elapsed)}</td
                      ><td
                        ><button class="link" disabled={working} on:click={() => openAttempt(a.id)}
                          >Lihat Hasil</button
                        ></td
                      ></tr
                    >{/each}</tbody
                >
              </table>{:else}<div class="empty">
                <h3>Belum ada riwayat</h3>
                <p>Selesaikan sesi pertama untuk melihat hasil dan pembahasannya.</p>
                <button class="primary" on:click={() => go('tryout')}>Pilih Tryout</button>
              </div>{/if}
          </div>
        {:else if view === 'bank' && owner}<div class="page-title">
            <div>
              <h1>Bank Soal</h1>
              <span class="muted">Rawat kumpulan soal, bangun latihan yang bermakna.</span>
            </div>
            <button
              class="primary"
              on:click={() => {
                questionEdit = null;
                questionModal = true;
              }}><Icon name="plus" />Tambah Soal</button
            >
          </div>
          <div class="toolbar">
            <input
              aria-label="Cari soal"
              placeholder="Cari soal atau topik…"
              bind:value={search}
            /><select aria-label="Filter status soal" bind:value={status}
              ><option value="all">Semua status</option><option value="ready">Siap Digunakan</option
              ><option value="draft">Draft</option><option value="archived">Diarsipkan</option
              ></select
            >
          </div>
          <div class="card" style="padding:0">
            {#if filteredQuestions.length}<table class="desktop-table">
                <thead
                  ><tr
                    ><th>Soal</th><th>Bagian & topik</th><th>Kesulitan</th><th>Status</th><th
                      >Aksi</th
                    ></tr
                  ></thead
                ><tbody
                  >{#each filteredQuestions as q}<tr
                      ><td
                        ><strong>{q.text.slice(0, 95)}{q.text.length > 95 ? '…' : ''}</strong><br
                        /><span class="small muted">Pilihan ganda · v{q.version}</span
                        >{#if q.demo}<span class="badge demo">Demo</span>{/if}</td
                      ><td>{q.section}<br /><span class="small muted">{q.topic}</span></td><td
                        >{q.difficulty}</td
                      ><td
                        ><span class="badge" class:good={q.status === 'ready' && !q.archived}
                          >{q.archived
                            ? 'Diarsipkan'
                            : q.status === 'ready'
                              ? 'Siap Digunakan'
                              : 'Draft'}</span
                        ></td
                      ><td
                        ><div class="actions">
                          <button
                            class="link"
                            on:click={() => {
                              questionEdit = q;
                              questionModal = true;
                            }}>Edit</button
                          ><button class="link" on:click={() => duplicate(q)}>Duplikat</button
                          ><button class="link" disabled={working} on:click={() => archive(q)}
                            >{q.archived ? 'Pulihkan' : 'Arsipkan'}</button
                          >
                        </div></td
                      ></tr
                    >{/each}</tbody
                >
              </table>{:else}<div class="empty">
                <h3>Belum ada soal.</h3>
                <p>Tambahkan soal pertamamu untuk mulai menyusun latihan.</p>
                <button
                  class="primary"
                  on:click={() => {
                    questionEdit = null;
                    questionModal = true;
                  }}>Tambah Soal</button
                >
              </div>{/if}
          </div>
        {:else if view === 'packages' && owner}<div class="page-title">
            <div>
              <h1>Paket Ujian</h1>
              <span class="muted">Susun bagian, pilih soal, dan atur ritme pengerjaan.</span>
            </div>
            <button
              class="primary"
              on:click={() => {
                packageEdit = null;
                packageModal = true;
              }}><Icon name="plus" />Buat Paket</button
            >
          </div>
          <div class="card table-wrap">
            {#if store.packages.length}<table class="desktop-table">
                <thead
                  ><tr
                    ><th>Nama paket</th><th>Mode</th><th>Soal / durasi</th><th>Status</th><th
                      >Aksi</th
                    ></tr
                  ></thead
                ><tbody
                  >{#each store.packages as p}<tr
                      ><td
                        ><strong>{p.name}</strong>{#if p.demo}<span class="badge demo"
                            >Paket Demo</span
                          >{/if}</td
                      ><td>{p.mode === 'simulasi' ? 'Simulasi' : 'Latihan'}</td><td
                        >{p.sections.reduce((n, s) => n + s.questionIds.length, 0)} soal · {p.sections.reduce(
                          (n, s) => n + s.duration,
                          0,
                        )} menit</td
                      ><td
                        ><span class="badge" class:good={p.status === 'ready'}
                          >{p.status === 'ready' ? 'Siap Dikerjakan' : 'Draft'}</span
                        ></td
                      ><td
                        ><div class="actions">
                          <button
                            class="link"
                            on:click={() => {
                              packageEdit = p;
                              packageModal = true;
                            }}>Edit</button
                          ><button
                            class="link"
                            on:click={() => {
                              detail = p;
                              go('detail');
                            }}>Lihat Detail</button
                          >
                        </div></td
                      ></tr
                    >{/each}</tbody
                >
              </table>{:else}<div class="empty">
                <h3>Belum ada paket</h3>
                <p>Buat paket dari soal yang siap digunakan.</p>
              </div>{/if}
          </div>
        {:else if view === 'result' && attempt}<Results
            a={attempt}
            {practice}
            history={() => go('history')}
            retry={() =>
              attempt?.practiceTopic
                ? practice(attempt.practiceTopic, attempt.sections[0].name)
                : action(() => start({ packageId: attempt!.packageId }))}
          />
        {:else if view === 'settings'}<Settings
            user={store.user}
            updated={async () => {
              store = await api<Bootstrap>('bootstrap');
            }}
          />{/if}
        <div class="footer-note">RuangSNBT · Satu langkah kecil, setiap hari.</div>{/if}
    </main>
  </div>{/if}
{#if questionModal}<QuestionEditor
    initial={questionEdit}
    close={() => (questionModal = false)}
    saved={() => saved('Soal')}
  />{/if}{#if packageModal && store}<PackageEditor
    initial={packageEdit}
    questions={store.questions}
    close={() => (packageModal = false)}
    saved={() => saved('Paket')}
  />{/if}{#if topic}<PracticeDialog {topic} close={() => (topic = null)} {start} />{/if}
