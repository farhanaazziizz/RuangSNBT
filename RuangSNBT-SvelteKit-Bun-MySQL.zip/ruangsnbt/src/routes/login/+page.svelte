<script lang="ts">
  let email = '',
    password = '',
    busy = false,
    message = '';
  async function submit() {
    busy = true;
    message = '';
    try {
      const r = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const d = await r.json();
      if (!r.ok) throw Error(d.message);
      location.href = '/';
    } catch (e) {
      message = e instanceof Error ? e.message : 'Login gagal. Coba lagi.';
    } finally {
      busy = false;
    }
  }
</script>

<div class="login-wrap">
  <div class="card login-card">
    <div class="brand"><img src="/icon.svg" alt="" /><span>Ruang<span>SNBT</span></span></div>
    <h1>Selamat datang kembali</h1>
    <p class="muted">Masuk untuk melanjutkan perjalanan belajarmu.</p>
    <form on:submit|preventDefault={submit}>
      <div class="field">
        <label for="email">Email</label><input
          id="email"
          type="email"
          bind:value={email}
          autocomplete="username"
          required
        />
      </div>
      <div class="field">
        <label for="password">Kata sandi</label><input
          id="password"
          type="password"
          bind:value={password}
          autocomplete="current-password"
          required
        />
      </div>
      {#if message}<div class="notice warning" role="alert">{message}</div>{/if}<button
        class="primary"
        disabled={busy}
        style="width:100%">{busy ? 'Memeriksa…' : 'Masuk'}</button
      >
    </form>
    <p class="muted small" style="margin-top:24px">
      Akun peserta dibuat oleh pemilik. Hubungi pemilik jika memerlukan akses atau penggantian kata
      sandi.
    </p>
  </div>
</div>
